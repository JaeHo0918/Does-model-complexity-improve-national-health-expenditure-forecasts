﻿Heliyon 재현자료 패키지 - 2026년 11월 16일

대상 원고(이번에 확인된 파일):
  user_manuscript/Heliyon_Final_Manuscript_formatted.docx
  논문 제목: Does model complexity improve national health-expenditure forecasts? Income-stratified and temporal evidence from 41 countries

자료와 재현 프로그램:
  source/historical_analysis_20261107/core/data/raw/source_dataset_762_utf8.csv
  source/historical_analysis_20261107/core/data/analysis/
  source/historical_analysis_20261107/core/metadata/variable_codebook.csv
  source/historical_analysis_20261107/core/run_all.py
  source/historical_analysis_20261107/additional/
  source/final_revision_20261114/
  expanded_outputs/
  run_expanded_analysis.py
  verify_expanded_results.py
  requirements_expanded.txt
  README_REPLICATION_KO.md (기존 분석 재현 상세안내)

실행 안내:
  Python 3.13 기반 환경에서 requirements_expanded.txt를 참고하여 패키지 설치
  (압축해제한 디렉터리에서) python run_expanded_analysis.py
  (압축해제한 디렉터리에서) python verify_expanded_results.py
  과거 본분석 재현용 명령 및 의존성은 source/historical_analysis_20261107/core/README.md 참고

확인 사항과 한계:
- 수집 이후 762개 국가-연도 관측치가 남은 분석용 패널과 예측값, 결과표, 코드, 그림, 검증기록이 포함되어 있음.
- 최초 4,216행 병합자료 및 모든 원천자료의 최초 다운로드 시점/당시 데이터 빈티지는 이 패키지로 완전히 복원할 수 없음.
- 기존 원본 재현 ZIP에 들어 있는 manuscript/Heliyon_Health_Expenditure_Submission_Final_20261116.docx는 이번에 제공된 formatted 원고와 다른 버전임.
  혼동 방지를 위해 두 버전을 모두 보존했음. 별도 수치 대조 없이 어느 버전이 모든 표 및 부록과 완전히 동일하다고 단정하지 않음.
- 원래 재현 ZIP 내부의 README, 소스, 결과물, 기록, SHA-256 manifest는 원본대로 보존됨.
- 2021~2023년은 주 사후평가 기간이며, 2024년은 표본 커버리지가 제한된 보조 민감도 분석임.

자료 사용시 표/그림 번호 및 실제 수치는 원고 버전과 비교하십시오.
