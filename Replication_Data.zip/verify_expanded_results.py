#!/usr/bin/env python3
"""Reconcile the submission manuscript with the archived empirical outputs.

Run from the package root. No raw source downloads are performed by this script.
"""
from pathlib import Path
import re,json,hashlib
import numpy as np
import pandas as pd
from docx import Document
from docx.oxml.ns import qn

BASE=Path(__file__).resolve().parent
OUT=BASE/'expanded_outputs'
DOC=BASE/'manuscript/Heliyon_Health_Expenditure_Submission_Final_20261116.docx'
PRIOR=BASE/'verification/Reference_Manuscript_20261114.docx'
checks=[]
def check(name,ok,details=''):
 checks.append({'name':name,'passed':bool(ok),'details':str(details)})
 if not ok:print('FAILED:',name,details)
def nfloat(s):return float(str(s).replace('−','-').replace('–','-'))
def canonical(s):
 s=s.replace('−','-').replace('Gov./GDP','Government/GDP').replace('Govt/GDP','Government/GDP')
 s=s.replace('postperiod','post-period').replace('Postperiod','Post-period')
 s=s.replace('preperiod','pre-period').replace('Preperiod','Pre-period')
 return ' '.join(s.split())
def matrix(t):return [[canonical(c.text) for c in row.cells] for row in t.rows]

doc=Document(DOC);prior=Document(PRIOR)
check('Word contains 14 data tables',len(doc.tables)==14,len(doc.tables))
check('Word contains eight inline figures',len(doc.inline_shapes)==8,len(doc.inline_shapes))
check('Word title preserved',doc.paragraphs[0].text.startswith('Does model complexity improve national health-expenditure forecasts?'))
check('Reference-year caution retained',any('historical release' in p.text or 'historical first-release' in p.text for p in doc.paragraphs))
check('Exploratory subgroup work appropriately described',sum('exploratory' in p.text.lower() for p in doc.paragraphs)>5)
check('No unwarranted income-moderation conclusion',not any('significant income moderation' in p.text.lower() and 'not' not in p.text.lower() for p in doc.paragraphs))
check('Submission replication filename matched',any('Heliyon_Health_Expenditure_Replication_Final_20261116.zip' in p.text for p in doc.paragraphs))

# Existing 11 tables must retain every numerical value and all row/column layouts.
old_tables=[matrix(t) for t in prior.tables]
new_tables=[matrix(t) for t in doc.tables]
for i,x in enumerate(old_tables,1):
 check(f'Legacy Table {i} values/layout preserved',x in new_tables)

for num in range(1,14):
 check(f'Table {num} caption unique',sum(p.text.startswith(f'Table {num}. ') for p in doc.paragraphs)==1)
check('Appendix Table A1 caption unique',sum(p.text.startswith('Table A1.') for p in doc.paragraphs)==1)
for num in range(1,9):
 check(f'Figure {num} caption unique',sum(p.text.startswith(f'Figure {num}. ') for p in doc.paragraphs)==1)

# Validate embedded figure file bytes against canonical archive images.
blobs=[]
for el in doc.element.body:
 for b in el.xpath('.//a:blip'):
  blobs.append(doc.part.related_parts[b.get(qn('r:embed'))].blob)
for i,b in enumerate(blobs,1):
 if i<=5:src=BASE/f'source/final_revision_20261114/figures/Figure_{i}.png'
 else:
  names={6:'Figure_6_annual_model_skill.png',7:'Figure_7_income_period_heterogeneity.png',8:'Figure_8_ratio_component_diagnostic.png'}
  src=OUT/names[i]
 check(f'Figure {i} matches source image SHA-256',src.is_file() and hashlib.sha256(b).hexdigest()==hashlib.sha256(src.read_bytes()).hexdigest())

# All current bibliography entries must have sequential numbers and DOI hyperlinks.
paras=doc.paragraphs
rstart=next(i for i,p in enumerate(paras) if p.text=='References')
ref_ps=[p for p in paras[rstart+1:] if re.match(r'^\d+\.\s',p.text)][:34]
check('Exactly 34 reference entries',len(ref_ps)==34)
check('Bibliography is numbered 1-34',[int(p.text.split('.',1)[0]) for p in ref_ps]==list(range(1,35)))
check('All bibliography entries have DOI text',all('https://doi.org/' in p.text for p in ref_ps))
check('All DOI URLs have internal relationship hyperlinks',all(p._p.xpath('.//w:hyperlink') for p in ref_ps))
check('All 34 DOI hyperlink destinations match displayed URLs',all(
    doc.part.rels[p._p.xpath('.//w:hyperlink')[0].get(qn('r:id'))].target_ref.rstrip('/')==
    re.findall(r'https://doi.org/\S+',p.text)[-1].rstrip('/')
    for p in ref_ps
))
cre=re.compile(r'(?<![A-Za-z0-9])\((\s*\d+(?:\s*[–-]\s*\d+)?(?:\s*[,;]\s*\d+(?:\s*[–-]\s*\d+)?)*\s*)\)')
order=[]
for p in paras[:rstart]:
 for m in cre.finditer(p.text):
  for piece in re.split('[,;]',m.group(1)):
   if '–' in piece or '-' in piece:
    a,b=[int(v) for v in re.split('[–-]',piece)];rr=range(a,b+1)
   else:rr=[int(piece)]
   for v in rr:
    if v not in order:order.append(v)
check('In-text citations first occur sequentially 1-34',order==list(range(1,35)),order)

# Empirical checks against computation saved in expanded_outputs.
key11=('Outcome','GDPpc stratum','Window','N','Pers. RMSE','ARX RMSE','ARX skill (%)')
key12=('Outcome','Contrast','Countries','High−low gain','p','Holm p')
key13=('Observed years','Consecutive pairs','Δ ln CHEpc','Δ ln GDPpc','Δ ln CHE/GDP','Mean |residual|')
byhead={tuple(cell.text for cell in t.rows[0].cells):t for t in doc.tables}
for k in [key11,key12,key13]:check('Table has expected headers '+k[0],k in byhead)
if key11 in byhead:
 t=byhead[key11];d=pd.read_csv(OUT/'income_strata_performance_country_bootstrap.csv')
 check('Table 11 row count',len(t.rows)==13)
 for row in t.rows[1:]:
  o,g,w,n,pr,ar,skill=[c.text for c in row.cells]
  target={'CHE/GDP':'CHE/GDP','Government/GDP':'Government/GDP'}[o]
  group={'Lower half':'At/below-median','Higher half':'Above-median'}[g]
  win={'2013–2020':'Pre 2013–2020','2021–2023':'Post 2021–2023','2021+2023':'Post omit 2022'}[w]
  z=d[(d.Outcome==target)&(d.Income_stratum==group)&(d.Window==win)].iloc[0]
  check('Table 11 source agreement '+':'.join([o,g,w]),int(n)==int(z.N) and abs(nfloat(pr)-z.RMSE_Persistence)<=.0005 and abs(nfloat(ar)-z.RMSE_ARX_LASSO)<=.0005 and abs(nfloat(skill)-z.MSE_skill_ARX_pct)<=.05)
if key12 in byhead:
 t=byhead[key12];d=pd.read_csv(OUT/'income_heterogeneity_tests_exploratory.csv')
 check('Table 12 row count',len(t.rows)==5)
 for row in t.rows[1:]:
  o,cl,n,diff,p,padj=[c.text for c in row.cells]
  target={'CHE/GDP':'CHE/GDP','Government/GDP':'Government/GDP'}[o]
  contrast={'2021–2023 gain':'post_gain','Post-minus-pre gain':'change_post_minus_pre_gain'}[cl]
  z=d[(d.Outcome==target)&(d.Contrast==contrast)].iloc[0]
  check('Table 12 source agreement '+':'.join([o,contrast]),int(n)==int(z.N_country) and abs(nfloat(diff)-z.High_minus_low_mean_gain)<.000051 and abs(nfloat(p)-z.permutation_two_sided_p)<.00051 and abs(nfloat(padj)-z.holm_p_two_outcomes)<.00051)
if key13 in byhead:
 t=byhead[key13];d=pd.read_csv(OUT/'ratio_components_summary_2013_2020.csv')
 check('Table 13 row count',len(t.rows)==3)
 for row in t.rows[1:]:
  name,n,che,gdp,ratio,res=[c.text for c in row.cells]
  z=d[d.Window==name].iloc[0]
  ok=int(n)==int(z.N_pairs) and abs(nfloat(che)-z.mean_delta_ln_CHE_per_capita)<.000051 and abs(nfloat(gdp)-z.mean_delta_ln_GDP_per_capita)<.000051 and abs(nfloat(ratio)-z.mean_delta_ln_CHE_GDP)<.000051 and abs(nfloat(res)-z.MAE_log_identity_residual)<.000051
  check('Table 13 source agreement '+name,ok)

# Ensure principal estimates remain unchanged (Table 3 and Table 6).
t3=doc.tables[2];t6=doc.tables[5]
check('Core LASSO RMSE is 0.414',t3.rows[1].cells[2].text=='0.414')
check('Core persistence RMSE is 0.433',next(r for r in t3.rows if r.cells[0].text=='Persistence').cells[2].text=='0.433')
check('Principal postperiod CHE n=120 and negative skill',t6.rows[1].cells[2].text=='120' and abs(nfloat(t6.rows[1].cells[6].text)+12.6)<1e-8)
check('Principal government n=121 and negative skill',any(r.cells[0].text=='Government/GDP' and r.cells[2].text=='121' and abs(nfloat(r.cells[6].text)+9.3)<1e-8 for r in t6.rows[1:]))

# Supplementary S1-S13 exist in the supplied additional Word file.
sdoc=BASE/'source/historical_analysis_20261107/supplement/Supplementary_Material_1_Reconciled_v2026-11-07.docx'
if sdoc.exists():
 sup=Document(sdoc);st='\n'.join(p.text for p in sup.paragraphs)
 for n in range(1,14):check(f'Supplementary Table S{n} exists',bool(re.search(r'\bTable\s+S'+str(n)+r'\b',st)))

result={'checks_total':len(checks),'checks_passed':sum(k['passed'] for k in checks),'checks_failed':sum(not k['passed'] for k in checks),'details':checks}
(OUT/'expanded_docx_numeric_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
(BASE/'verification/FINAL_SUBMISSION_QA_20261116.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print('FINAL CHECKS:',result['checks_passed'],'/',result['checks_total'])
assert result['checks_failed']==0
