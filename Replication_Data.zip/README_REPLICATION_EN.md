# Health expenditure forecasting: final submission reproducibility package
Date: 16 November 2026

## Submission manuscript
The manuscript is `manuscript/Heliyon_Health_Expenditure_Submission_Final_20261116.docx`. Its complete bibliography is numbered in order of first citation (1–34), and the study includes Tables 1–13 plus Appendix Table A1 and Figures 1–8. The file `verification/Reference_Manuscript_20261114.docx` is retained **only** as a comparison baseline for the historic tables and should not be submitted as the new manuscript.

## Reproducibility and verification
Unzip this archive in a writable directory. With the Python packages listed in `requirements_expanded.txt`, run:

```
python run_expanded_analysis.py
python verify_expanded_results.py
```

The first script reproduces the exploratory income-stratum, calendar-year sensitivity and 2020 expenditure/GDP component analyses from saved observations and model predictions. The second script verifies manuscript table contents, numerical values, figure hashes, numbering and first-citation order. A machine-readable QA report is saved at `verification/FINAL_SUBMISSION_QA_20261116.json`. The submission bibliography and its DOI addresses are recorded at `verification/REFERENCE_DOI_AUDIT.txt`.

## Contents and interpretation
The `source/` directory retains the prior analysis archive, model-estimation programs, original reproducibility outputs and Supplementary Material 1 (Tables S1–S13). The `expanded_outputs/` directory contains the income-stratified performance, permutation tests, matched-country and year-specific comparisons, 2020 ratio accounting, associated Figures 6–8, and validation logs. The primary post-period is 2021–2023; selective 2024 coverage is assessed only as a sensitivity exercise.

The income strata are within-sample groups based on pre-2013 GDP per capita, not World Bank income categories. Country-level resampling does not model common calendar-year shocks. Removing 2022 or 2024 from evaluation changes **scoring only**, not the previously fitted forecasting model. Historical reference-year alignment should not be interpreted as verified point-in-time data availability. The 2020 ratio component exercise is descriptive and does not identify a causal pandemic effect.

The SHA-256 manifest `MANIFEST_EXPANDED_SHA256.txt` covers every other archived file. The original scripts and data have not been deliberately altered in the final editorial pass; only the manuscript, submission-oriented verification instructions and reports are refreshed.
