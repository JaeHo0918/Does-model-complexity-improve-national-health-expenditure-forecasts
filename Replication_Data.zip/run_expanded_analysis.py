#!/usr/bin/env python3
"""Exploratory economic heterogeneity, regime sensitivity and ratio accounting.

Inputs: archived observations/predictions only; never fabricates data, imputes
missing source observations, or refits predictive models using evaluation data.
The income strata are an explicit median split of the 2007-2012 historical
country log GDP per-capita means (not official WB categories). Country bootstrap
preserves within-country forecast histories but cannot account for common-year
shock dependence. All findings are descriptive/exploratory.
"""
from pathlib import Path
import numpy as np, pandas as pd, json, hashlib
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
ARCH=ROOT/'source/historical_analysis_20261107'
OUT=ROOT/'expanded_outputs'
OUT.mkdir(exist_ok=True)
RNG=np.random.default_rng(20261115)
B=5000
P=12000
raw=pd.read_csv(ARCH/'core/data/raw/source_dataset_762_utf8.csv').sort_values(['Country_EN','Year'])
br=pd.read_csv(ARCH/'core/outputs/predictions/postperiod_bridge_predictions.csv')
core=pd.read_csv(ARCH/'core/outputs/predictions/core_predictions.csv')
assert not raw.duplicated(['Country_EN','Year']).any()
assert not br.duplicated(['Country_EN','Year','Outcome']).any()
assert set(br.Outcome)=={'CHE/GDP','Government/GDP'}
assert len(raw)==762 and raw.Country_EN.nunique()==41 and len(br)==925
baseline=raw[raw.Year.between(2007,2012)].groupby('Country_EN').agg(baseline_logGDPpc=('GDP_PC','median'), baseline_obs=('GDP_PC','size'))
assert baseline.index.nunique()==41
cut=float(baseline.baseline_logGDPpc.median())
baseline['income_stratum']=np.where(baseline.baseline_logGDPpc>cut,'Above-median','At/below-median')
baseline.to_csv(OUT/'baseline_income_2007_2012.csv',float_format='%.10f')
# Robustness: alternative as-of-2012 grouping uses the last available pre-2013 GDPpc
last_pre2013=raw[raw.Year<=2012].sort_values(['Country_EN','Year']).groupby('Country_EN').tail(1).set_index('Country_EN').GDP_PC
alt_label=last_pre2013.gt(last_pre2013.median()).map({True:'Above-median',False:'At/below-median'})
alt=(baseline[['income_stratum']].join(alt_label.rename('last_pre2013_stratum'),how='left'))
alt['switches']=alt.income_stratum!=alt.last_pre2013_stratum
alt.to_csv(OUT/'income_stratum_alternative_last_pre2013_check.csv')
assert not alt.switches.any(), alt[alt.switches].to_string()
br=br.merge(baseline.reset_index(),on='Country_EN',how='left',validate='many_to_one')
assert not br.income_stratum.isna().any()
br['sqerr_Persistence']=(br.y-br.Persistence)**2
br['sqerr_ARX_LASSO']=(br.y-br['ARX-LASSO'])**2
br['sqerr_AR1']=(br.y-br['AR(1)'])**2
br['gain_ARX_over_Persistence']=br.sqerr_Persistence-br.sqerr_ARX_LASSO
br['gain_ARX_over_AR1']=br.sqerr_AR1-br.sqerr_ARX_LASSO

def metric(d):
    if not len(d):return {}
    rp=float(np.sqrt(d.sqerr_Persistence.mean()))
    rl=float(np.sqrt(d.sqerr_ARX_LASSO.mean()))
    ra=float(np.sqrt(d.sqerr_AR1.mean()))
    return dict(N=len(d),countries=int(d.Country_EN.nunique()),
        RMSE_Persistence=rp,RMSE_ARX_LASSO=rl,RMSE_AR1=ra,
        MSE_skill_ARX_pct=100*(1-rl**2/rp**2),
        Delta_RMSE_ARX_minus_Persistence=rl-rp,
        mean_squared_loss_gain_P_minus_ARX=float(d.gain_ARX_over_Persistence.mean()),
        mean_squared_loss_gain_AR1_minus_ARX=float(d.gain_ARX_over_AR1.mean()),
        share_ARX_wins_observation=float((d.gain_ARX_over_Persistence>0).mean()))

def bootstrap_country(d, draws=B, seed=23):
    """Country-path bootstrap; inference does not model cross-country year clustering."""
    rng=np.random.default_rng(seed)
    country=d.groupby('Country_EN').agg(n=('Year','size'),
        es_p=('sqerr_Persistence','sum'),es_l=('sqerr_ARX_LASSO','sum'),es_a=('sqerr_AR1','sum'))
    k=len(country)
    vals=country[['n','es_p','es_l','es_a']].to_numpy(float)
    ix=rng.integers(0,k,size=(draws,k))
    sample=vals[ix].sum(axis=1)
    rmsp=np.sqrt(sample[:,1]/sample[:,0]);rmsl=np.sqrt(sample[:,2]/sample[:,0]);rmsa=np.sqrt(sample[:,3]/sample[:,0])
    out={'ci_delta_RMSE_2p5':float(np.quantile(rmsl-rmsp,.025)),
         'ci_delta_RMSE_97p5':float(np.quantile(rmsl-rmsp,.975)),
         'ci_skill_pct_2p5':float(np.quantile(100*(1-rmsl**2/rmsp**2),.025)),
         'ci_skill_pct_97p5':float(np.quantile(100*(1-rmsl**2/rmsp**2),.975)),
         'ci_gain_ARX_vs_AR1_2p5':float(np.quantile((sample[:,3]-sample[:,2])/sample[:,0],.025)),
         'ci_gain_ARX_vs_AR1_97p5':float(np.quantile((sample[:,3]-sample[:,2])/sample[:,0],.975))}
    return out

# Annual same-information bridge, excluding 2024 from main tables
annual=[]
for target,dd in br.groupby('Outcome'):
 for year,d in dd.groupby('Year'):
  annual.append({'Outcome':target,'Year':int(year),**metric(d)})
pd.DataFrame(annual).to_csv(OUT/'annual_bridge_performance_2013_2024.csv',index=False,float_format='%.10f')

# Matched country scope for 2021-23 (all three years observed), pre vs post
matched_country_rows=[];strata_rows=[];period_rows=[];post_country=[]
for oi,target in enumerate(['CHE/GDP','Government/GDP']):
 dd=br[br.Outcome==target]
 matched=set(dd[dd.Year.between(2021,2023)].groupby('Country_EN').Year.nunique().loc[lambda x:x==3].index)
 dm=dd[dd.Country_EN.isin(matched)]
 for period, years in [('Pre 2013–2020',range(2013,2021)),('Post 2021–2023',range(2021,2024)),('Post omit 2022',(2021,2023)),('Post 2021–2024 (2024 incomplete)',range(2021,2025)),('Pre 2013–2019',range(2013,2020)),('Year 2020',(2020,)),('Year 2021',(2021,)),('Year 2022',(2022,)),('Year 2023',(2023,))]:
  d=dm[dm.Year.isin(years)]
  if len(d)==0:continue
  period_rows.append({'Outcome':target,'Window':period,'Matched_countries':len(matched),**metric(d),**bootstrap_country(d,seed=20261115+oi*30+len(period_rows))})
  for group,dg in d.groupby('income_stratum'):
   if period not in ['Pre 2013–2020','Post 2021–2023','Post omit 2022','Post 2021–2024 (2024 incomplete)']:continue
   strata_rows.append({'Outcome':target,'Window':period,'Income_stratum':group,**metric(dg),
                      **bootstrap_country(dg,seed=20261115+oi*30+len(strata_rows))})
 for (country,inc),cg in dm.groupby(['Country_EN','income_stratum']):
  pre=cg[cg.Year.between(2013,2020)].gain_ARX_over_Persistence.mean()
  post=cg[cg.Year.between(2021,2023)].gain_ARX_over_Persistence.mean()
  pm=cg[cg.Year.between(2021,2023)]
  post_country.append({'Outcome':target,'Country_EN':country,'Income_stratum':inc,
     'baseline_logGDPpc':float(cg.baseline_logGDPpc.iloc[0]),
     'pre_gain':float(pre),'post_gain':float(post),'change_post_minus_pre_gain':float(post-pre),
     'post_wins_ARX':bool(pm.sqerr_ARX_LASSO.mean()<pm.sqerr_Persistence.mean()),
     'post_n':len(pm)})

pd.DataFrame(period_rows).to_csv(OUT/'matched_period_performance_country_bootstrap.csv',index=False,float_format='%.10f')
pd.DataFrame(strata_rows).to_csv(OUT/'income_strata_performance_country_bootstrap.csv',index=False,float_format='%.10f')
ct=pd.DataFrame(post_country)
ct.to_csv(OUT/'country_level_matched_shift.csv',index=False,float_format='%.10f')

# Significance of between-income stratum heterogeneous predictive gains; only
# country-level permutation tests. Post-vs-pre shifted differential additionally.
# Significance claims must not be based on these alone because common-year shocks.
permutation=[]
for target,dd in ct.groupby('Outcome'):
 low=dd.Income_stratum=='At/below-median';hi=~low
 nlow=int(low.sum()); n=len(dd)
 for col in ['post_gain','change_post_minus_pre_gain']:
  x=dd[col].to_numpy(float)
  obs=float(x[hi.to_numpy()].mean()-x[low.to_numpy()].mean())
  rr=np.random.default_rng(20261115+len(permutation)*137)
  absnull=np.empty(P)
  for i in range(P):
   sh=rr.permutation(n)
   absnull[i]=abs(x[sh[nlow:]].mean()-x[sh[:nlow]].mean())
  p=float((1+(absnull>=abs(obs)).sum())/(P+1))
  permutation.append({'Outcome':target,'Contrast':col,'N_country':n,'Lower_stratum_n':nlow,
                      'Higher_stratum_n':n-nlow,'High_minus_low_mean_gain':obs,'permutation_two_sided_p':p,
                      'draws':P,'test_unit':'country; unadjusted for common forecast-year shocks'})
  
# also Spearman continuous vs post gain and shift
for target,dd in ct.groupby('Outcome'):
 for col in ['post_gain','change_post_minus_pre_gain']:
  res=spearmanr(dd.baseline_logGDPpc,dd[col])
  permutation.append({'Outcome':target,'Contrast':'spearman_'+col,'N_country':len(dd),
                      'High_minus_low_mean_gain':float(res.statistic),'permutation_two_sided_p':float(res.pvalue),
                      'draws':0,'test_unit':'Country Spearman; asymptotic p ignores shared-year shocks'})
perm_df=pd.DataFrame(permutation)
# Holm adjustment within the two outcome families for income tests only.
for contrast in ['post_gain','change_post_minus_pre_gain']:
 sub=perm_df[perm_df.Contrast==contrast].sort_values('permutation_two_sided_p')
 pval=sub.permutation_two_sided_p.to_numpy()
 adj=np.maximum.accumulate(pval * np.arange(len(pval),0,-1))
 perm_df.loc[sub.index,'holm_p_two_outcomes']=np.minimum(1,adj)
perm_df.to_csv(OUT/'income_heterogeneity_tests_exploratory.csv',index=False,float_format='%.10f')

# 2020 numerator-vs-denominator descriptive component accounting on observed
# consecutive-year pairs; this is NOT a decomposition of OOS prediction errors.
recs=[]
for c,d in raw.groupby('Country_EN'):
 d=d.sort_values('Year')
 for j in range(1,len(d)):
  p,drow=d.iloc[j-1],d.iloc[j]
  if drow.Year-p.Year!=1:continue
  # dlog CHEpc and GDPpc are approximate, because first data are rounded and from different producers
  delta_ratio=np.log(drow.HEALTH_GDP/p.HEALTH_GDP)
  delta_che_pc=drow.HE_PC_USD-p.HE_PC_USD
  delta_gdp_pc=drow.GDP_PC-p.GDP_PC
  recs.append({'Country_EN':c,'Year':int(drow.Year),
               'delta_ln_ratio':delta_ratio,'delta_ln_health_spend_pc':delta_che_pc,
               'delta_ln_GDP_pc':delta_gdp_pc,
               'identity_residual':delta_ratio-(delta_che_pc-delta_gdp_pc)})
comp=pd.DataFrame(recs)
comp.to_csv(OUT/'observed_ratio_log_change_components_consecutive_years.csv',index=False,float_format='%.10f')
comp_rows=[]
for window,ymin,ymax in [('2013–2019',2013,2019),('2020',2020,2020),('2013–2020',2013,2020)]:
 d=comp[comp.Year.between(ymin,ymax)]
 comp_rows.append({'Window':window,'N_pairs':len(d),'N_country':d.Country_EN.nunique(),
   'mean_delta_ln_CHE_GDP':d.delta_ln_ratio.mean(),
   'mean_delta_ln_CHE_per_capita':d.delta_ln_health_spend_pc.mean(),
   'mean_delta_ln_GDP_per_capita':d.delta_ln_GDP_pc.mean(),
   'mean_residual':d.identity_residual.mean(),
   'MAE_log_identity_residual':d.identity_residual.abs().mean(),
   'pct_CHE_ratio_increased':100*(d.delta_ln_ratio>0).mean(),
   'pct_health_spend_pc_increased':100*(d.delta_ln_health_spend_pc>0).mean(),
   'pct_GDP_pc_declined':100*(d.delta_ln_GDP_pc<0).mean()})
pd.DataFrame(comp_rows).to_csv(OUT/'ratio_components_summary_2013_2020.csv',index=False,float_format='%.10f')

# Independently reconcile outputs with existing archived main table numerical values
prior=pd.read_csv(ROOT/'source/final_revision_20261114/tables/Table_06_primary_and_sensitivity.csv')
tests=[]
for _,r in prior.iterrows():
    outcome='CHE/GDP' if r.Outcome=='CHE_GDP' else 'Government/GDP'
    dd=br[br.Outcome==outcome]
    if '2021-2023 (primary' in r.Window: d=dd[dd.Year.between(2021,2023)]
    elif '2021+2023+2024' in r.Window:d=dd[dd.Year.isin([2021,2023,2024])]
    elif '2021+2023' in r.Window:d=dd[dd.Year.isin([2021,2023])]
    elif '2021-2024' in r.Window:d=dd[dd.Year.between(2021,2024)]
    else:continue
    m=metric(d)
    for col, key in [('N','N'),('RMSE_persistence','RMSE_Persistence'),('RMSE_ARX_LASSO','RMSE_ARX_LASSO'),('RMSE_AR1','RMSE_AR1'),('MSE_skill_pct','MSE_skill_ARX_pct')]:
        val=float(r[col]);val2=float(m[key]);tol=1e-6 if col=='N' else 1.5e-6
        tests.append({'Outcome':outcome,'Window':r.Window,'Check':col,'original_value':val,'new_value':val2,'abs_diff':abs(val-val2),'PASS':abs(val-val2)<tol})
ver=pd.DataFrame(tests);ver.to_csv(OUT/'reconciliation_with_prior_Table06.csv',index=False,float_format='%.10f')
assert ver.PASS.all(),ver[~ver.PASS].to_string()

# Figures: minimalist grayscale only, easy monochrome printing
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'figure.dpi':140,'savefig.dpi':240})
fig,axes=plt.subplots(1,2,figsize=(10.4,3.6),sharex=True,sharey=True)
for ax,t in zip(axes,['CHE/GDP','Government/GDP']):
 d=pd.DataFrame(annual);d=d[(d.Outcome==t)&d.Year.between(2013,2023)]
 ax.axhline(0,color='0.3',lw=.9)
 ax.axvspan(2019.5,2020.5,color='0.85',alpha=.55)
 ax.axvspan(2021.5,2022.5,color='0.75',alpha=.35)
 ax.plot(d.Year,d.MSE_skill_ARX_pct,marker='o',markersize=4.4,color='0.13',lw=1.65)
 ax.set_xticks([2013,2015,2017,2019,2021,2023]);ax.tick_params(axis='x',labelrotation=30)
 ax.set_title(t,weight='bold',loc='left',fontsize=11)
 ax.grid(axis='y',alpha=.18)
ax=axes[0];ax.set_ylabel('ARX-LASSO MSE skill relative to persistence (%)')
fig.text(.51,.01,'Positive skill favors ARX-LASSO; shaded years are 2020 and 2022.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.055,1,1));fig.savefig(OUT/'Figure_6_annual_model_skill.png',bbox_inches='tight');plt.close(fig)

sg=pd.DataFrame(strata_rows)
fig,axes=plt.subplots(1,2,figsize=(10.2,3.6),sharey=True)
for ax,t in zip(axes,['CHE/GDP','Government/GDP']):
 q=sg[(sg.Outcome==t)&sg.Window.isin(['Pre 2013–2020','Post 2021–2023'])]
 groups=['At/below-median','Above-median']; windows=['Pre 2013–2020','Post 2021–2023']
 x=np.array([0,1]);width=.32
 for j,w in enumerate(windows):
  z=q[q.Window==w].set_index('Income_stratum').loc[groups]
  ax.bar(x+(j-.5)*width,z.MSE_skill_ARX_pct,width=width,fill=(j==0),facecolor=('0.3' if j==0 else 'white'),edgecolor='0.2',linewidth=1.15,label=w)
 ax.axhline(0,color='0.2',lw=.9);ax.set_xticks(x,['Lower GDPpc','Higher GDPpc']);ax.set_title(t,loc='left',weight='bold',fontsize=11);ax.grid(axis='y',alpha=.17)
axes[0].set_ylabel('ARX-LASSO MSE skill (%)')
axes[1].legend(frameon=False,fontsize=9,loc='upper right')
fig.text(.5,.012,'Sample-median log GDP per capita, computed using 2007–2012 country histories; matched countries only.',ha='center',fontsize=8.6)
fig.tight_layout(rect=(0,.06,1,1));fig.savefig(OUT/'Figure_7_income_period_heterogeneity.png',bbox_inches='tight');plt.close(fig)

# Figure showing component drivers of 2020 (descriptive mean log annual changes)
cs=pd.read_csv(OUT/'ratio_components_summary_2013_2020.csv').set_index('Window')
fig,ax=plt.subplots(figsize=(7.6,3.55))
periods=['2013–2019','2020'];x=np.arange(2);width=.23
for idx,(key,lab,gray) in enumerate([('mean_delta_ln_CHE_per_capita','Health spending per capita','0.25'),
                                    ('mean_delta_ln_GDP_per_capita','GDP per capita','0.58'),
                                    ('mean_delta_ln_CHE_GDP','CHE/GDP ratio','0.82')]):
 ax.bar(x+(idx-1)*width,[cs.loc[p,key] for p in periods],width,label=lab,color=gray,edgecolor='0.2',linewidth=.6)
ax.axhline(0,color='0.25',lw=1);ax.set_xticks(x,periods);ax.set_ylabel('Mean annual change in natural logarithms')
ax.legend(frameon=False,loc='upper left',fontsize=9);ax.grid(axis='y',alpha=.15)
fig.tight_layout();fig.savefig(OUT/'Figure_8_ratio_component_diagnostic.png',bbox_inches='tight');plt.close(fig)

summary={
  'date':'2026-11-15','classification':'Ex ante within-sample split by median country log GDPpc (2007–2012); not World Bank categories',
  'alternative_last_pre2013_group_changes':int(alt.switches.sum()),'income_cutpoint_logGDPpc':cut,'low_group_n':int((baseline.income_stratum=='At/below-median').sum()),'high_group_n':int((baseline.income_stratum=='Above-median').sum()),
  'total_bridge_N':len(br),'che_post_primary_N':int(len(br[(br.Outcome=='CHE/GDP')&br.Year.between(2021,2023)])),
  'government_post_primary_N':int(len(br[(br.Outcome=='Government/GDP')&br.Year.between(2021,2023)])),
  'country_block_bootstrap_repetitions':B,'permutation_repetitions':P,
  'prior_table_06_checks_passed':int(ver.PASS.sum()),'prior_table_06_checks_failed':int((~ver.PASS).sum()),
  'interpretation_boundaries':['income subgroup contrasts exploratory and not official World Bank income groups',
   'country-block confidence intervals do not account for common forecast-year shocks',
   '2022 omission changes scoring sample; does not re-train either model',
   '2020 component decomposition is descriptive, non-causal and uses legacy logged per-capita series available through 2020',
   'post-2020 bridge is retrospective current-release, not historical point-in-time vintage evaluation',
   'source panel construction is attributed to author-provided merge procedure; this analysis begins with retained panel/forecasts'],
}
(OUT/'analysis_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
print('==income tests==');print(perm_df.to_string(index=False))
print('==matched post strata==');print(sg[sg.Window=='Post 2021–2023'][['Outcome','Income_stratum','N','countries','RMSE_Persistence','RMSE_ARX_LASSO','MSE_skill_ARX_pct','ci_skill_pct_2p5','ci_skill_pct_97p5']].to_string(index=False))
print('==matched shift==');print(pd.DataFrame(period_rows).query("Window in ['Pre 2013–2020','Post 2021–2023']")[['Outcome','Window','N','countries','MSE_skill_ARX_pct']].to_string(index=False))
print('==2020 decomposition==');print(pd.DataFrame(comp_rows).to_string(index=False))
print('reconciliation',int(ver.PASS.sum()),'/',len(ver))
