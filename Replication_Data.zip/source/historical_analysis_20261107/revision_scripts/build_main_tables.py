#!/usr/bin/env python3
"""Export the ten revised manuscript tables from the archived numerical results.

This is a reporting/export step. It does not refit any forecasting model or
reconstruct unavailable upstream source-query and complete-case selection stages.
The original core and additional numerical files are read without modification.

Example:
    python revision_scripts/build_main_tables.py --archive-root . --output-dir revision_outputs/tables

Requires pandas and numpy. All paths are resolved relative to --archive-root;
the process working directory is otherwise immaterial.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


def scalar(value, places=3, signed=False):
    return format(float(value), f"{'+' if signed else ''}.{places}f")


def interval(low, high, places=4, signed=False):
    return f"[{scalar(low, places, signed)}, {scalar(high, places, signed)}]"


def export_tables(archive_root: Path, output_dir: Path):
    root = archive_root.resolve()
    out = output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    input_hashes = {}
    mappings = []

    def csv(relative):
        path = root / relative
        input_hashes[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
        return pd.read_csv(path)

    def js(relative):
        path = root / relative
        input_hashes[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
        return json.loads(path.read_text(encoding="utf-8"))

    def save(number, columns, rows, generator, inputs, notes):
        name = f"Table_{number:02d}.csv"
        pd.DataFrame(rows, columns=columns).to_csv(out / name, index=False, encoding="utf-8-sig")
        mappings.append({
            "item": f"Table {number}",
            "reporting_script": "revision_scripts/build_main_tables.py",
            "numerical_generator": generator,
            "output_file": f"revision_outputs/tables/{name}",
            "source_files": " | ".join(inputs),
            "notes": notes,
        })

    raw_path = "core/data/raw/source_dataset_762_utf8.csv"
    aligned_path = "core/data/analysis/analysis_dataset_one_year_ahead.csv"
    extension_path = "core/data/raw/worldbank_latest_original_country_extension.csv"
    corepred_path = "core/outputs/predictions/core_predictions.csv"
    transfer_path = "core/outputs/predictions/transfer_predictions.csv"
    postpred_path = "core/outputs/predictions/postperiod_bridge_predictions.csv"
    raw = csv(raw_path)
    aligned = csv(aligned_path)
    extension = csv(extension_path)
    core = csv(corepred_path)
    transfer = csv(transfer_path)
    post = csv(postpred_path)
    assert len(raw) == 762 and raw.Country_EN.nunique() == 41
    assert len(aligned) == 709 and aligned.Country_EN.nunique() == 40
    assert len(core) == 307 and core.Country_EN.nunique() == 40
    assert len([c for c in aligned if c.startswith("L1_") and c != "L1_HEALTH_GDP"]) == 21

    def counts(frame):
        return str(int(frame.Country_EN.nunique())), str(len(frame))

    cg = transfer[transfer.Protocol == "Retrospective grouped"]
    st = transfer[transfer.Protocol == "Spatiotemporal holdout"]
    pche = post[(post.Outcome == "CHE/GDP") & post.Year.between(2021, 2024)]
    pgov = post[(post.Outcome == "Government/GDP") & post.Year.between(2021, 2024)]
    save(1, ["Sample or protocol", "Years", "Countries", "Forecast cases", "Purpose"], [
        ["Core complete-case panel", "2000–2020", *counts(raw), "21 structural predictors; outcome and audit variables"],
        ["Aligned one-year pairs", "2001–2020", *counts(aligned), "Target at t; predictors and outcome at t − 1"],
        ["Primary rolling evaluation", "2013–2020", *counts(core), "Pre-2013 tuning; expanding estimation windows"],
        ["Retrospective country-grouped validation", "2001–2020", str(cg.Country_EN.nunique()), f"{len(cg)} per model", "Excluded countries; not chronologically restricted"],
        ["Spatiotemporal country holdout", "2013–2020", str(st.Country_EN.nunique()), f"{len(st)} per model", "Excluded countries and only prior years"],
        ["Latest-release CHE/GDP extension", "2021–2024", *counts(pche), f"2024: {int((pche.Year == 2024).sum())} countries; lower-dimensional ARX"],
        ["Latest-release government/GDP extension", "2021–2024", *counts(pgov), f"2024: {int((pgov.Year == 2024).sum())} countries; lower-dimensional ARX"],
    ], "Direct retained-data counts; core/src/reproduce_analysis.py: core_rolling_predictions, transfer_protocols, postperiod_bridge", [raw_path, aligned_path, corepred_path, transfer_path, postpred_path],
        "Retained sample sizes are directly counted. Protocol descriptions are reporting metadata. This table does not reconstruct the 4,216-row pre-filter merge.")

    audit_path = "core/outputs/data_audit.json"
    audit = js(audit_path)
    metadata = extension[["Country_EN", "Region", "IncomeGroup"]].drop_duplicates()
    composition = raw.merge(metadata, on="Country_EN", how="left", validate="many_to_one")
    high_income = float((composition.IncomeGroup == "High income").mean() * 100)
    n_equal_one = int((raw.EQUAL_PROT_INDEX == 1).sum())
    save(2, ["Item", "Audit finding", "Analytical treatment", "Purpose"], [
        ["HE_PC_USD and HE_PC_PPP", "Mechanically proximate to HEALTH_GDP", "Excluded from primary models", f"Avoid target reconstruction; audit R² = {scalar(audit['reconstruction_R2'], 4)}"],
        ["EQUAL_PROT_INDEX", f"Near-constant ({n_equal_one}/{len(raw)} equal 1.0)", "Excluded", "Avoid unstable splits and attribution"],
        ["RENEW_ENERGY", f"Stored range {raw.RENEW_ENERGY.min():g}-{raw.RENEW_ENERGY.max():g}", "Multiplied by 10,000", "Interpret as percentage points"],
        ["Timing language", "No real-time vintages or publication lags", "Reference-year-aligned evaluation", "Avoid overstating ex ante availability"],
        ["Outcome precision", "HEALTH_GDP rounded to 0.1 point", "1,000 coherent perturbations", "Test ranking against resolution uncertainty"],
        ["Sample composition", f"{high_income:.1f}% of observations high income", "Report country income/region composition", "Bound external-validity claims"],
        ["Initial merged file", "4,216-row pre-filter file unavailable", "Data-selection limitation disclosed", "Clarify limits of missing-data assessment"],
    ], "core/src/reproduce_analysis.py: data_audit_and_denominator; direct retained-data checks", [raw_path, extension_path, audit_path],
        "The 4,216 initial records and 1,000 rounding replications are documented counts, not reconstructed pre-filter rows. The archive records only aggregate sample selection; no stepwise deletion log is supplied. Region/income labels are those retained in the extension file.")

    perf_path = "core/outputs/tables/table_core_performance.csv"
    perf = csv(perf_path)
    save(3, ["Model", "N", "RMSE", "MAE", "R²", "MSE skill (%)", "rMAE"], [
        [r.Model, str(int(r.N)), scalar(r.RMSE), scalar(r.MAE), scalar(r.R2), scalar(r.MSE_skill_pct, 1), scalar(r.rMAE)]
        for r in perf.itertuples(index=False)
    ], "core/src/reproduce_analysis.py: core_rolling_predictions", [perf_path, corepred_path],
        "rMAE is test-period model MAE divided by persistence MAE on the same rows; it is not training-scaled MASE.")

    validation_path = "core/outputs/tables/table_validation_protocols.csv"
    validation = csv(validation_path)
    las = perf[perf.Model == "LASSO"].iloc[0]
    rows4 = [["Primary rolling", "Dynamic LASSO", scalar(las.RMSE), scalar(las.MSE_skill_pct, 1), "Known countries; future years"]]
    for protocol, model, interpretation in [
        ("Spatiotemporal holdout", "Dynamic LASSO", "Excluded countries; only prior years"),
        ("Spatiotemporal holdout", "AR(1)", "Excluded countries; only prior years"),
        ("Spatiotemporal holdout", "Persistence", "Excluded countries; only prior years"),
        ("Retrospective grouped", "Dynamic LASSO", "Geographic transfer; all training years"),
        ("Primary rolling", "Structural k-NN", "No lagged outcome"),
    ]:
        r = validation[(validation.Protocol == protocol) & (validation.Model == model)].iloc[0]
        rows4.append([protocol, model, scalar(r.RMSE), scalar(r.MSE_skill_pct, 1), interpretation])
    save(4, ["Protocol", "Model", "RMSE", "MSE skill (%)", "Interpretation"], rows4,
        "core/src/reproduce_analysis.py: core_rolling_predictions, transfer_protocols", [perf_path, validation_path, transfer_path],
        "Country folds use KFold(5, shuffle=True, random_state=0) and a fixed alpha of 0.01. The supplied transfer routine does not perform nested within-fold penalty tuning.")

    uncertainty_path = "core/outputs/tables/table_uncertainty.csv"
    uncertainty_summary_path = "core/outputs/uncertainty_summary.json"
    additional_summary_path = "additional/frontiers_new_results/verified_analysis_summary.json"
    unc = csv(uncertainty_path)
    us = js(uncertainty_summary_path)
    additional = js(additional_summary_path)
    rows5 = []
    for i, r in enumerate(unc.itertuples(index=False)):
        scope = f"{int(r.country_wins)}/40 country wins" if i < 2 else "Country-block pairwise comparison"
        rows5.append([r.Comparison, scalar(r.Delta_RMSE, 4), interval(r.CI_low, r.CI_high), scalar(r.two_way_p), scope])
    rows5.extend([
        ["Alternative 16-candidate maximum test (year blocks)", "—", "—", scalar(additional['sixteen_candidate_reality_check_new']['year_bootstrap_p']), "Alternative candidate set; year-block bootstrap"],
        ["Rounding perturbation", f"{scalar(us['rounding_median'], 4)} median", interval(*us['rounding_ci']), f"P(better) = {scalar(us['rounding_p_better'])}", "1,000 source-level perturbations"],
        ["Primary 16-candidate reality check", "—", "—", scalar(us['reality_check_p'], 4), "Archived candidate roster; 5,000 country-block resamples"],
    ])
    save(5, ["Comparison or test", "ΔRMSE", "95% interval", "p value / probability", "Scope"], rows5,
        "core/src/reproduce_analysis.py: uncertainty, country_bootstrap_delta, two_way_loss_p, reality_check; additional/frontiers_additional_analysis.py: alternative model-search sensitivity", [uncertainty_path, uncertainty_summary_path, additional_summary_path],
        "The main paired CI uses 5,000 complete-country resamples, seed 0, and 2.5th/97.5th linear percentile quantiles. The additional S1 country CI uses seed 20261031 and is a separate Monte Carlo rerun of the same forecast contrast. Paired loss-test p values are two-sided. Country win counts are descriptive.")

    posttable_path = "core/outputs/tables/table_postperiod.csv"
    posttable = csv(posttable_path)
    outcome_names = {"CHE/GDP": "Current health expenditure / GDP", "Government/GDP": "Government health expenditure / GDP"}
    save(6, ["Outcome", "Window", "N", "Persistence RMSE", "ARX-LASSO RMSE", "AR(1) RMSE", "ARX skill (%)"], [
        [outcome_names[r.Outcome], r.Window.replace("-", "–"), str(int(r.N)), scalar(r.Persistence_RMSE), scalar(r.ARX_LASSO_RMSE), scalar(r.AR1_RMSE), scalar(r.ARX_skill_pct, 1)]
        for r in posttable.itertuples(index=False)
    ], "core/src/reproduce_analysis.py: postperiod_bridge", [posttable_path, postpred_path],
        "The 2021–2024 window includes partial 2024 coverage. The independent restricted ARX script reproduces the same forecasts and documents pre-2013 tuning.")

    bridgetable_path = "core/outputs/tables/table_same_information_bridge.csv"
    bridge = csv(bridgetable_path)
    save(7, ["Outcome", "Window", "N", "Persistence RMSE", "AR(1) RMSE", "ARX-LASSO RMSE", "ARX skill (%)"], [
        [r.Outcome, r.Window.replace("-", "–"), str(int(r.N)), scalar(r.Persistence_RMSE), scalar(r.AR1_RMSE), scalar(r.ARX_LASSO_RMSE), scalar(r.ARX_skill_pct, 1)]
        for r in bridge.itertuples(index=False)
    ], "core/src/reproduce_analysis.py: postperiod_bridge", [bridgetable_path, postpred_path],
        "Current-release information set and annual refits are held constant across periods. This is not a historical-vintage experiment.")

    robustness_path = "core/outputs/tables/table_robustness.csv"
    strict_horizon_path = "additional/frontiers_new_results/horizon_strict_origin_results.csv"
    robustness = csv(robustness_path)
    horizons = csv(strict_horizon_path)
    rows8 = []
    r = robustness[robustness.Target_or_restriction == "1-year CHE/GDP"].iloc[0]
    rows8.append(["1-year CHE/GDP", str(int(r.N)), scalar(r.LASSO_RMSE), scalar(r.Persistence_RMSE), scalar(r.LASSO_skill_pct, 1)])
    for h in [2, 3]:
        r = horizons[horizons.horizon_years == h].iloc[0]
        rows8.append([f"{h}-year CHE/GDP (origin-corrected)", str(int(r.n_evaluation)), scalar(r.RMSE_LASSO), scalar(r.RMSE_persistence), scalar(r.MSE_skill_pct, 1)])
    for key, display in [
        ("1-year derived government/GDP", "1-year derived government/GDP"),
        ("1-year CHE/GDP, 2013-2019", "1-year CHE/GDP, 2013–2019"),
        ("1-year CHE/GDP, >=15 histories", "1-year CHE/GDP, ≥15 histories"),
    ]:
        r = robustness[robustness.Target_or_restriction == key].iloc[0]
        rows8.append([display, str(int(r.N)), scalar(r.LASSO_RMSE), scalar(r.Persistence_RMSE), scalar(r.LASSO_skill_pct, 1)])
    save(8, ["Target or restriction", "N", "LASSO RMSE", "Persistence RMSE", "LASSO skill (%)"], rows8,
        "core/src/reproduce_analysis.py: robustness (rows 1, 4–6); additional/frontiers_additional_analysis.py: strict horizon section (rows 2–3)", [robustness_path, strict_horizon_path, "additional/frontiers_new_results/horizon_strict_predictions.csv"],
        "For h=2 and h=3, use only the origin-corrected additional outputs (N=305 and 300). The legacy core 2/3-year rows are preserved in the historical archive but are not the revised manuscript results.")

    shap_path = "core/outputs/tables/table_shap_full.csv"
    shap = csv(shap_path).head(10)
    labels = {
        "L1_HEALTH_GDP": "Lagged health expenditure share", "L1_EXPR_INFO_FREE": "Freedom of expression/information",
        "L1_YOUTH_UNEMP": "Youth unemployment", "L1_GHG_LOG": "ln GHG emissions", "L1_UNEMP": "Total unemployment",
        "L1_PHE_CHE": "Public financing share", "L1_POP_LOG": "ln population", "L1_CA_GDP": "Current-account balance",
        "L1_FISCAL_BAL_GDP": "Fiscal balance", "L1_JUSTICE_ACCESS": "Access to justice",
    }
    save(9, ["Predictor", "Mean |SHAP|", "95% country-block interval", "Share (%)", "Selected origins"], [
        [labels[r.Predictor], scalar(r.Mean_abs_SHAP), interval(r.CI_low, r.CI_high, 3), scalar(r.Share_pct, 1), f"{int(r.Selected_origins)}/8"]
        for r in shap.itertuples(index=False)
    ], "core/src/reproduce_analysis.py: shap_analysis", [shap_path, "core/outputs/predictions/rolling_shap_values.csv"],
        "Linear interventional SHAP relative to each training-window mean. Country-block interval uses 5,000 resamples, seed 1. Attribution is not causal or an accuracy decomposition.")

    matched_path = "additional/frontiers_new_results/matched_country_period_comparison.csv"
    matched_unc_path = "additional/frontiers_new_results/matched_country_paired_uncertainty.csv"
    matched = csv(matched_path)
    matched_unc = csv(matched_unc_path)
    rows10 = []
    for target, end in [("CHE_GDP", 2023), ("CHE_GDP", 2024), ("PUBLIC_GDP", 2023), ("PUBLIC_GDP", 2024)]:
        ms = matched[(matched.target == target) & (matched.matched_2021_to == end)]
        pre = ms[ms.window == "2013-2020"].iloc[0]
        later = ms[ms.window == f"2021-{end}"].iloc[0]
        ui = matched_unc[(matched_unc.target == target) & (matched_unc.end_year == end)].iloc[0]
        rows10.append(["CHE/GDP" if target == "CHE_GDP" else "Government/GDP", f"2021–{end}", str(int(later.countries_common)), scalar(pre.ARX_MSE_skill_pct, 1, True), scalar(later.ARX_MSE_skill_pct, 1, True), interval(ui.country_95CI_low, ui.country_95CI_high, 4, True)])
    save(10, ["Outcome", "Postperiod", "Countries (n)", "Preperiod MSE skill (%)", "Postperiod MSE skill (%)", "Postperiod ΔRMSE 95% CI"], rows10,
        "additional/frontiers_additional_analysis.py: matched country section; additional/matched_uncertainty.py", [matched_path, matched_unc_path, "additional/frontiers_new_results/restricted_post_period_all_predictions.csv"],
        "The final column contains CI bounds only; the header is corrected accordingly. Matched bootstrap uses 5,000 resamples with a sequential RNG stream seeded 927.")

    pd.DataFrame(mappings).to_csv(out / "main_table_sources.csv", index=False, encoding="utf-8-sig")
    report = {
        "purpose": "Numerical table export and consistency checks from retained archived outputs, not a full model-pipeline rerun",
        "input_hashes_sha256": input_hashes,
        "sources": mappings,
        "checks": {"table_count": len(mappings), "core_N": len(raw), "one_year_pairs": len(aligned), "core_forecasts": len(core),
                   "core_countries": int(core.Country_EN.nunique()), "equal_protection_at_one": n_equal_one,
                   "high_income_observations": int((composition.IncomeGroup == "High income").sum()),
                   "high_income_pct": high_income, "pre_filter_counts_independently_reconstructed": False},
        "primary_country_interval": [float(unc.iloc[0].CI_low), float(unc.iloc[0].CI_high)],
        "independent_additional_country_interval": additional["core_uncertainty"]["country_95ci_delta_RMSE"],
        "notes": [
            "The primary and additional intervals use the same forecast rows, but different seeded Monte Carlo streams (0 and 20261031).",
            "The 4,216 initial-record count is author-reported; 3,454 is its arithmetic difference from the verified 762 retained rows. No stepwise selection log is supplied.",
            "All original analytical input and result files are read only. Model-fitting scripts and execution commands are identified separately in the source map.",
        ],
    }
    (out / "table_export_verification.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    report = export_tables(args.archive_root, args.output_dir)
    print(json.dumps({"tables_exported": report["checks"]["table_count"], "output_directory": str(args.output_dir.resolve()), "model_pipeline_refitted": False}, indent=2))


if __name__ == "__main__":
    main()
