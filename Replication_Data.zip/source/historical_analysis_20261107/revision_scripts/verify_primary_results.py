#!/usr/bin/env python3
"""Independently verify selected health-expenditure results from retained CSVs.

Usage:
  python verify_primary_results.py --archive-root PATH --output-dir PATH

This intentionally limited verification does not import or execute the complete
archived pipeline, which additionally requires statsmodels, xgboost and lightgbm.
It does not reconstruct the unavailable 4,216-row upstream merge or historical
data vintages. Source observations and original archived outputs are read-only.

The estimator definitions, tuning blocks, training cutoffs and inferential
formulae follow core/src/reproduce_analysis.py and
additional/frontiers_additional_analysis.py. For the intercept-only loss model,
the two-way CGM covariance is implemented algebraically with the same finite
sample corrections instead of requiring statsmodels.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import importlib.util
import itertools
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import Lasso, LinearRegression
from sklearn.metrics import r2_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


ATOL = 1e-10
RTOL = 1e-12
SIGNFLIP_EPSILON = 1e-12  # Exact comparison tolerance in the additional script.
ALPHAS = [0.001, 0.003, 0.01, 0.03, 0.1]
VALIDATION_BLOCKS = [(2007, 2008), (2009, 2010), (2011, 2012)]
STRUCTURAL = [
    "PHE_CHE", "OOP_CHE", "GDP_PC", "GDP_DEFL", "PPI", "CPI", "CA_GDP",
    "FISCAL_BAL_GDP", "REV_GDP", "EXP_GDP", "FERT_RATE", "YOUTH_UNEMP",
    "UNEMP", "POP_LOG", "EGAL_DEM_INDEX", "EXPR_INFO_FREE", "JUSTICE_ACCESS",
    "RENEW_ENERGY", "WATER_PC", "PM25_LOG", "GHG_LOG",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rmse(y, p) -> float:
    return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))


def metrics(y, p, persistence) -> dict:
    y, p, persistence = map(np.asarray, (y, p, persistence))
    return {
        "RMSE": rmse(y, p),
        "MAE": float(np.mean(np.abs(y - p))),
        "R2": float(r2_score(y, p)),
        "MSE_skill_pct": float(100 * (1 - np.mean((y-p)**2) / np.mean((y-persistence)**2))),
        "rMAE": float(np.mean(np.abs(y-p)) / np.mean(np.abs(y-persistence))),
    }


def lasso(alpha: float, max_iter: int = 100000, random_state=None) -> Pipeline:
    # Explicit default solver settings preserve the archived statistical logic.
    return Pipeline([
        ("scale", StandardScaler()),
        ("model", Lasso(alpha=alpha, max_iter=max_iter, tol=1e-4,
                        fit_intercept=True, selection="cyclic", random_state=random_state)),
    ])


class Audit:
    def __init__(self, root: Path):
        self.root = root
        self.inputs = {}
        self.checks = []

    def read_csv(self, relative: str) -> pd.DataFrame:
        self.inputs[relative] = sha256(self.root / relative)
        return pd.read_csv(self.root / relative)

    def read_json(self, relative: str):
        self.inputs[relative] = sha256(self.root / relative)
        return json.loads((self.root / relative).read_text(encoding="utf-8"))

    def equal(self, name, actual, expected):
        passed = bool(actual == expected)
        self.checks.append({"check": name, "passed": passed, "actual": actual, "expected": expected})
        return passed

    def close(self, name, actual, expected):
        a, e = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
        shape_ok = a.shape == e.shape
        passed = bool(shape_ok and np.allclose(a, e, atol=ATOL, rtol=RTOL, equal_nan=True))
        finite = np.isfinite(a) & np.isfinite(e) if shape_ok else np.array([], dtype=bool)
        max_abs = float(np.max(np.abs(a[finite]-e[finite]))) if finite.any() else 0.0
        entry = {"check": name, "passed": passed, "actual_shape": list(a.shape),
                 "expected_shape": list(e.shape), "max_abs_difference": max_abs,
                 "absolute_tolerance": ATOL, "relative_tolerance": RTOL}
        if a.ndim == 0 and e.ndim == 0:
            entry.update(actual=float(a), expected=float(e))
        self.checks.append(entry)
        return passed

    def frames(self, name, actual, expected, keys, columns):
        a = actual.sort_values(keys).reset_index(drop=True)
        e = expected.sort_values(keys).reset_index(drop=True)
        keys_ok = a[keys].equals(e[keys])
        self.checks.append({"check": name + " keys", "passed": bool(keys_ok),
                            "actual_rows": len(a), "expected_rows": len(e), "keys": keys})
        if keys_ok:
            for col in columns:
                self.close(name + " " + col, a[col].to_numpy(), e[col].to_numpy())
        return keys_ok


def tune(df, features, target, max_iter=100000, random_state=None):
    records = []
    for alpha in ALPHAS:
        y, p = [], []
        for start, end in VALIDATION_BLOCKS:
            tr = df[df.Year < start]
            te = df[df.Year.between(start, end)]
            fit = lasso(alpha, max_iter, random_state).fit(tr[features], tr[target])
            y.extend(te[target]); p.extend(fit.predict(te[features]))
        records.append({"alpha": alpha, "validation_RMSE": rmse(y, p),
                        "pre2013_validation_MSE": float(np.mean((np.asarray(y)-np.asarray(p))**2))})
    table = pd.DataFrame(records)
    return float(table.loc[table.validation_RMSE.idxmin(), "alpha"]), table


def rebuild_core(audit: Audit):
    raw = audit.read_csv("core/data/raw/source_dataset_762_utf8.csv")
    source = raw.copy()
    source["RENEW_ENERGY"] = source["RENEW_ENERGY"] * 10000
    source["GGHE_GDP"] = source.HEALTH_GDP * source.PHE_CHE / 100
    ready = audit.read_csv("core/data/analysis/source_dataset_analysis_ready.csv")
    numerical = [c for c in ready if c not in ("Country", "Country_KO", "Country_EN")]
    audit.frames("retained source transformations", source, ready,
                 ["Country_EN", "Year"], numerical)
    audit.equal("retained source row count", int(len(source)), 762)
    audit.equal("retained source country count", int(source.Country_EN.nunique()), 41)
    audit.equal("source country-year duplicates", int(source.duplicated(["Country_EN", "Year"]).sum()), 0)

    features = ["L1_" + c for c in STRUCTURAL + ["HEALTH_GDP"]]
    previous = source[["Country_EN", "Year"] + STRUCTURAL + ["HEALTH_GDP"]].copy()
    previous["Year"] = previous["Year"] + 1
    previous = previous.rename(columns={c: "L1_" + c for c in STRUCTURAL + ["HEALTH_GDP"]})
    rebuilt = source[["Country_EN", "Year", "HEALTH_GDP"]].merge(
        previous, on=["Country_EN", "Year"], how="inner", validate="one_to_one")
    rebuilt["TIME_TREND"] = rebuilt.Year - 2000
    rebuilt = rebuilt.sort_values(["Country_EN", "Year"]).reset_index(drop=True)
    stored = audit.read_csv("core/data/analysis/analysis_dataset_one_year_ahead.csv")
    audit.equal("core feature order", features, [c for c in stored if c.startswith("L1_")])
    audit.frames("reconstructed consecutive one-year input", rebuilt, stored,
                 ["Country_EN", "Year"], ["HEALTH_GDP"] + features + ["TIME_TREND"])
    audit.equal("aligned core row count", int(len(rebuilt)), 709)
    audit.equal("aligned core country count", int(rebuilt.Country_EN.nunique()), 40)
    return rebuilt, features


def refit_core(audit: Audit, core, features, output):
    selected, tuning = tune(core, features, "HEALTH_GDP")
    audit.equal("selected core LASSO penalty", selected, 0.01)
    reference_tuning = audit.read_csv("core/outputs/tables/tuning_core_lasso.csv")
    audit.frames("core pre-2013 tuning", tuning, reference_tuning, ["alpha"], ["validation_RMSE"])
    rows = []
    for year in range(2013, 2021):
        tr, te = core[core.Year < year], core[core.Year == year]
        result = te[["Country_EN", "Year", "HEALTH_GDP", "L1_HEALTH_GDP"]].copy()
        result["Persistence"] = te.L1_HEALTH_GDP.to_numpy()
        result["LASSO"] = lasso(selected).fit(tr[features], tr.HEALTH_GDP).predict(te[features])
        result["AR(1)"] = LinearRegression().fit(tr[["L1_HEALTH_GDP"]], tr.HEALTH_GDP).predict(te[["L1_HEALTH_GDP"]])
        result["Penalized AR-LASSO"] = lasso(0.001).fit(tr[["L1_HEALTH_GDP"]], tr.HEALTH_GDP).predict(te[["L1_HEALTH_GDP"]])
        rows.append(result)
    predictions = pd.concat(rows, ignore_index=True)
    stored = audit.read_csv("core/outputs/predictions/core_predictions.csv")
    columns = ["HEALTH_GDP", "L1_HEALTH_GDP", "Persistence", "LASSO", "AR(1)", "Penalized AR-LASSO"]
    audit.frames("refitted core predictions", predictions, stored, ["Country_EN", "Year"], columns)
    additional = audit.read_csv("additional/frontiers_new_results/core_predictions_16_candidates.csv")
    additional = additional.rename(columns={"actual": "HEALTH_GDP", "persistence": "Persistence", "lasso": "LASSO"})
    audit.frames("refitted core versus additional archived predictions", predictions, additional,
                 ["Country_EN", "Year"], ["HEALTH_GDP", "Persistence", "LASSO"])
    table = audit.read_csv("core/outputs/tables/table_core_performance.csv")
    computed = []
    for name in ["LASSO", "Persistence", "AR(1)", "Penalized AR-LASSO"]:
        entry = {"Model": name, "N": int(len(predictions)), **metrics(predictions.HEALTH_GDP, predictions[name], predictions.Persistence)}
        computed.append(entry)
        ref = table.loc[table.Model == name].iloc[0]
        for metric in ("N", "RMSE", "MAE", "R2", "MSE_skill_pct", "rMAE"):
            audit.close("core metric " + name + " " + metric, entry[metric], ref[metric])
    predictions.to_csv(output / "verified_core_predictions.csv", index=False)
    tuning.to_csv(output / "verified_core_tuning.csv", index=False)
    return predictions, stored, computed


def rebuild_extension(audit: Audit):
    reference = audit.read_csv("core/data/raw/worldbank_latest_original_country_extension.csv")
    extension = reference.sort_values(["Country_EN", "Year"]).reset_index(drop=True).copy()
    audit.equal("extension country-year duplicates", int(extension.duplicated(["Country_EN", "Year"]).sum()), 0)
    for base in ["CHE_GDP", "PUBLIC_GDP", "PUBLIC_CHE", "OOP_CHE"]:
        extension["L1_" + base] = extension.groupby("Country_EN")[base].shift(1)
    extension["Consecutive"] = extension.groupby("Country_EN").Year.diff().eq(1)
    audit.frames("reconstructed extension lags", extension, reference, ["Country_EN", "Year"],
                 ["L1_CHE_GDP", "L1_PUBLIC_GDP", "L1_PUBLIC_CHE", "L1_OOP_CHE", "Consecutive"])
    return extension


def refit_extension(audit: Audit, extension, output):
    configs = [
        ("CHE_GDP", "CHE/GDP", ["L1_CHE_GDP", "L1_PUBLIC_CHE", "L1_OOP_CHE"]),
        ("PUBLIC_GDP", "Government/GDP", ["L1_PUBLIC_GDP", "L1_OOP_CHE"]),
    ]
    predictions, tunings = [], []
    for target, outcome, features in configs:
        d = extension.dropna(subset=[target] + features).copy()
        d = d[d.Consecutive == True]
        # Same solver settings as the original additional sensitivity script.
        alpha, tuning = tune(d, features, target, max_iter=150000, random_state=0)
        audit.equal("restricted selected alpha " + target, alpha, 0.001)
        tuning["target"] = target
        tunings.append(tuning)
        for year in range(2013, 2025):
            tr, te = d[d.Year < year], d[d.Year == year]
            if te.empty:
                continue
            result = te[["Country_EN", "Year", target, features[0]]].rename(
                columns={target: "actual", features[0]: "persistence"}).copy()
            result["lasso"] = lasso(alpha, 150000, 0).fit(tr[features], tr[target]).predict(te[features])
            result["ar1"] = LinearRegression().fit(tr[[features[0]]], tr[target]).predict(te[[features[0]]])
            result["target"], result["alpha"], result["Outcome"] = target, alpha, outcome
            predictions.append(result)
    pred = pd.concat(predictions, ignore_index=True)
    tuning = pd.concat(tunings, ignore_index=True)
    stored_tuning = audit.read_csv("additional/frontiers_new_results/pre2013_restricted_alpha_validation.csv")
    audit.frames("restricted pre-2013 tuning", tuning, stored_tuning,
                 ["target", "alpha"], ["pre2013_validation_MSE"])
    additional = audit.read_csv("additional/frontiers_new_results/restricted_post_period_all_predictions.csv")
    audit.frames("refitted restricted versus additional predictions", pred, additional,
                 ["target", "Country_EN", "Year"], ["actual", "persistence", "lasso", "ar1", "alpha"])
    core_stored = audit.read_csv("core/outputs/predictions/postperiod_bridge_predictions.csv").rename(
        columns={"y": "actual", "Persistence": "persistence", "ARX-LASSO": "lasso", "AR(1)": "ar1"})
    audit.frames("refitted restricted versus core predictions", pred, core_stored,
                 ["Outcome", "Country_EN", "Year"], ["actual", "persistence", "lasso", "ar1"])
    reference_metrics = audit.read_csv("additional/frontiers_new_results/restricted_period_performance.csv")
    records = []
    for target, outcome, _ in configs:
        for start, end in [(2013, 2020), (2021, 2023), (2021, 2024)]:
            sub = pred[(pred.target == target) & pred.Year.between(start, end)]
            entry = {
                "target": target, "period": f"{start}-{end}", "N": int(len(sub)),
                "countries": int(sub.Country_EN.nunique()), "alpha": float(sub.alpha.iloc[0]),
                "RMSE_persistence": rmse(sub.actual, sub.persistence),
                "RMSE_ARX_LASSO": rmse(sub.actual, sub.lasso),
                "RMSE_AR1": rmse(sub.actual, sub.ar1),
                "ARX_MSE_skill_pct": metrics(sub.actual, sub.lasso, sub.persistence)["MSE_skill_pct"],
                "delta_RMSE_ARX_minus_persistence": rmse(sub.actual, sub.lasso) - rmse(sub.actual, sub.persistence),
            }
            records.append(entry)
            ref = reference_metrics[(reference_metrics.target == target) & (reference_metrics.period == entry["period"])].iloc[0]
            for field in ["N", "countries", "alpha", "RMSE_persistence", "RMSE_ARX_LASSO", "RMSE_AR1", "ARX_MSE_skill_pct", "delta_RMSE_ARX_minus_persistence"]:
                audit.close("restricted metric " + target + " " + entry["period"] + " " + field, entry[field], ref[field])
    pred.to_csv(output / "verified_restricted_predictions.csv", index=False)
    tuning.to_csv(output / "verified_restricted_tuning.csv", index=False)
    return records


def cgm_intercept_only(stored: pd.DataFrame):
    """CGM country + year - intersection with statsmodels-equivalent corrections."""
    df = stored.sort_values(["Year", "Country_EN"]).reset_index(drop=True)
    differential = ((df.HEALTH_GDP-df.Persistence)**2 - (df.HEALTH_GDP-df.LASSO)**2).to_numpy()
    n, k = len(differential), 1
    mean = float(differential.mean())
    residual = differential - mean
    cluster_scores = df[["Country_EN", "Year"]].assign(score=residual)

    def component(keys):
        summed = cluster_scores.groupby(keys).score.sum().to_numpy()
        groups = len(summed)
        correction = (groups / (groups-1)) * ((n-1) / (n-k))
        variance = float(correction * np.sum(summed**2) / (n*n))
        return variance, groups, correction

    vc, gc, cc = component(["Country_EN"])
    vy, gy, cy = component(["Year"])
    vi, gi, ci = component(["Country_EN", "Year"])
    variance = vc + vy - vi
    se = float(np.sqrt(variance))
    t_stat = mean / se
    degrees = min(gc, gy)-1
    p = float(2 * stats.t.sf(abs(t_stat), df=degrees))
    annual_sums = np.array([differential[df.Year.to_numpy() == yr].sum() for yr in sorted(df.Year.unique())])
    observed = abs(mean)
    null = np.array([abs(np.dot(np.array(signs), annual_sums) / n)
                     for signs in itertools.product([-1, 1], repeat=gy)])
    exceedances = int(np.sum(null >= observed-SIGNFLIP_EPSILON))
    sign_p = float(exceedances / len(null))
    return {
        "basis": "Archived paired prediction errors; no model rerun is needed for this inference check",
        "loss_differential": "Persistence squared error minus LASSO squared error",
        "N": n, "country_clusters": gc, "forecast_year_blocks": gy, "intersection_clusters": gi,
        "loss_gain_mean": mean, "variance_country": vc, "variance_year": vy,
        "variance_intersection": vi, "variance_two_way": variance, "SE_two_way": se,
        "t_stat": t_stat, "reference_degrees_of_freedom": degrees, "p_two_sided": p,
        "finite_sample_corrections": {"country": cc, "year": cy, "intersection": ci},
        "formula": "V = V_country + V_year - V_country_year; V_group = G/(G-1) * (n-1)/(n-k) * sum(cluster residual-score sums squared)/n^2; k=1",
        "year_signflip_exact_p_two_sided": sign_p, "signflip_patterns": len(null),
        "signflip_exceedances": exceedances, "signflip_comparison_epsilon": SIGNFLIP_EPSILON,
        "signflip_comparison": "abs(signed annual aggregate mean) >= abs(observed mean) - 1e-12",
        "interpretive_limit": "Forecast-year sign symmetry/exchangeability is an assumption; the eight blocks are not established to be serially independent",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    root, output = args.archive_root.resolve(), args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    # Never point the output folder at one of the archived input/output folders.
    protected = [root/"core/data", root/"core/outputs", root/"additional/frontiers_new_results"]
    if any(output == p or p in output.parents for p in protected):
        raise ValueError("Choose a separate verification output directory to preserve archived files.")
    audit = Audit(root)
    for relative in ["core/src/reproduce_analysis.py", "additional/frontiers_additional_analysis.py"]:
        audit.inputs[relative] = sha256(root / relative)
    report = {
        "verification_scope": "Selected primary and restricted models refitted from retained CSV observations, input alignment checked, and primary dependence inference independently recalculated",
        "full_pipeline_executed": False,
        "full_pipeline_limitation": "The original full pipeline was not run in this environment; statsmodels, xgboost and lightgbm are not required by this verifier. No full candidate-model, grouped-validation, horizon, SHAP or all-sensitivity rerun is claimed.",
        "upstream_provenance_limit": "The 4,216-row pre-filter merge, original provider extraction logs and historical publication vintages are not reconstructed.",
        "numerical_tolerances": {"absolute": ATOL, "relative": RTOL, "signflip_reference_epsilon": SIGNFLIP_EPSILON},
        "environment": {"python": platform.python_version(), **{
            pkg: importlib.metadata.version(pkg) for pkg in ["numpy", "pandas", "scipy", "scikit-learn"]}},
        "optional_full_pipeline_modules_available": {
            name: importlib.util.find_spec(name) is not None for name in ["statsmodels", "xgboost", "lightgbm"]},
        "core_model_protocol": {"alphas": ALPHAS, "pre2013_validation_blocks": VALIDATION_BLOCKS,
            "train_rule": "target Year < test Year", "evaluation_years": [2013, 2020],
            "standardization": "Training sample only, StandardScaler defaults", "lasso_solver_tol": 1e-4,
            "core_max_iter": 100000, "restricted_max_iter": 150000, "selection": "cyclic"},
    }
    try:
        core, features = rebuild_core(audit)
        refitted, archived, core_metrics = refit_core(audit, core, features, output)
        report["core_metrics"] = core_metrics
        extension = rebuild_extension(audit)
        report["restricted_metrics"] = refit_extension(audit, extension, output)
        inference = cgm_intercept_only(archived)
        report["primary_inference"] = inference
        recorded = audit.read_json("additional/frontiers_new_results/verified_analysis_summary.json")["core_inference"]
        for field in ["loss_gain_mean", "variance_country", "variance_year", "variance_two_way",
                      "SE_two_way", "t_stat", "p_two_sided", "year_signflip_exact_p_two_sided", "signflip_patterns"]:
            audit.close("primary inference " + field, inference[field], recorded[field])
        # Descriptive counts only; no independent-country sign-test p value.
        report["descriptive_country_wins"] = {}
        for comparator, expected in [("Persistence", 29), ("Penalized AR-LASSO", 27)]:
            wins = int(sum(rmse(g.HEALTH_GDP, g.LASSO) < rmse(g.HEALTH_GDP, g[comparator])
                           for _, g in refitted.groupby("Country_EN")))
            report["descriptive_country_wins"][comparator] = {"wins": wins, "countries": 40}
            audit.equal("descriptive country wins vs " + comparator, wins, expected)
    except Exception as exc:
        report["execution_error"] = {"type": type(exc).__name__, "message": str(exc)}
    report["source_file_sha256"] = audit.inputs
    report["source_integrity_unchanged"] = all(sha256(root / p) == h for p, h in audit.inputs.items())
    report["checks"] = audit.checks
    report["checks_passed"] = sum(item["passed"] for item in audit.checks)
    report["checks_failed"] = sum(not item["passed"] for item in audit.checks)
    report["selected_verification_passed"] = (
        "execution_error" not in report and report["checks_failed"] == 0 and report["source_integrity_unchanged"])
    (output / "primary_verification.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({key: report.get(key) for key in ["selected_verification_passed", "checks_passed", "checks_failed", "source_integrity_unchanged", "execution_error"]}, indent=2))
    if not report["selected_verification_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
