from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
count=0
for line in (root/'MANIFEST_SHA256.txt').read_text().splitlines():
    expected,relative=line.split('  ',1)
    path=root/relative
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:raise SystemExit('Checksum mismatch: '+relative)
    count += 1
print(f'PASS: {count} file hashes match the supplied manifest')
