#!/usr/bin/env python3
"""Recompute primary uncertainty from the archived observation-level forecasts.

This verification does not refit models or re-create upstream source data.
It requires numpy, pandas and scipy and writes only the requested JSON output.
"""

from __future__ import annotations

import argparse
from itertools import product
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


def verify(root: Path):
    core = pd.read_csv(root / "core/outputs/predictions/core_predictions.csv")
    extra = pd.read_csv(root / "additional/frontiers_new_results/core_predictions_16_candidates.csv")
    comparison = core.merge(extra, on=["Country_EN", "Year"], validate="one_to_one")
    max_differences = {
        "actual": float(np.max(np.abs(comparison.HEALTH_GDP - comparison.actual))),
        "LASSO": float(np.max(np.abs(comparison.LASSO - comparison.lasso))),
        "persistence": float(np.max(np.abs(comparison.Persistence - comparison.persistence))),
    }
    assert all(x == 0 for x in max_differences.values())
    n = len(core)
    rmse = lambda a, b: float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
    point = rmse(core.HEALTH_GDP, core.LASSO) - rmse(core.HEALTH_GDP, core.Persistence)
    groups = core.assign(sse_a=(core.HEALTH_GDP-core.LASSO)**2, sse_b=(core.HEALTH_GDP-core.Persistence)**2).groupby("Country_EN").agg(n=("Year", "size"), sse_a=("sse_a", "sum"), sse_b=("sse_b", "sum"))
    values = groups[["n", "sse_a", "sse_b"]].to_numpy(float)
    rng = np.random.default_rng(0)
    indices = rng.integers(0, len(values), size=(5000, len(values)))
    totals = values[indices].sum(axis=1)
    main_draws = np.sqrt(totals[:, 1] / totals[:, 0]) - np.sqrt(totals[:, 2] / totals[:, 0])
    main_interval = np.quantile(main_draws, [0.025, 0.975]).tolist()
    stored_draws = pd.read_csv(root / "core/outputs/bootstrap/bootstrap_LASSO_vs_Persistence.csv").delta_RMSE.to_numpy()
    max_draw_difference = float(np.max(np.abs(main_draws - stored_draws)))
    assert max_draw_difference < 1e-12

    # Reproduce the additional script's RNG order: 5,000 country draws followed
    # immediately by 5,000 forecast-year draws from the same seeded generator.
    rng = np.random.default_rng(20261031)
    extra = extra.sort_values(["Year", "Country_EN"]).reset_index(drop=True)
    intervals = {}
    for label, grouping in [("country", "Country_EN"), ("forecast_year", "Year")]:
        blocks = {key: frame.index.to_numpy() for key, frame in extra.groupby(grouping)}
        keys = list(blocks)
        y = extra.actual.to_numpy()
        a = extra.lasso.to_numpy()
        b = extra.persistence.to_numpy()
        draws = []
        for _ in range(5000):
            ids = np.concatenate([blocks[key] for key in rng.choice(keys, size=len(keys), replace=True)])
            draws.append(rmse(y[ids], a[ids]) - rmse(y[ids], b[ids]))
        intervals[label] = np.quantile(draws, [0.025, 0.975]).tolist()

    # Intercept-only CGM covariance equals the inclusion-exclusion sum of
    # cluster score squares divided by N^2, with G/(G-1) small-sample factors.
    loss = (core.HEALTH_GDP-core.Persistence)**2 - (core.HEALTH_GDP-core.LASSO)**2
    mean_loss = float(loss.mean())
    residual = loss - mean_loss
    frame = core[["Country_EN", "Year"]].copy()
    frame["residual"] = residual

    def covariance(group):
        totals = frame.groupby(group).residual.sum()
        g = len(totals)
        return float(g / (g-1) * np.sum(totals.to_numpy()**2) / n**2)

    vc = covariance("Country_EN")
    vy = covariance("Year")
    vi = covariance(["Country_EN", "Year"])
    variance = vc + vy - vi
    se = float(np.sqrt(variance))
    statistic = mean_loss / se
    degrees_freedom = min(core.Country_EN.nunique(), core.Year.nunique()) - 1
    p_two_sided = float(2 * stats.t.sf(abs(statistic), degrees_freedom))
    annual = core.assign(loss=loss).groupby("Year").loss.sum().to_numpy()
    distribution = [abs(np.dot(signs, annual) / n) for signs in product([-1, 1], repeat=len(annual))]
    signflip = float(np.mean(np.asarray(distribution) >= abs(mean_loss)-1e-12))
    reference = json.loads((root / "additional/frontiers_new_results/verified_analysis_summary.json").read_text())
    assert abs(p_two_sided-reference["core_inference"]["p_two_sided"]) < 1e-12
    assert abs(signflip-reference["core_inference"]["year_signflip_exact_p_two_sided"]) < 1e-12
    wins = {}
    for baseline in ["Persistence", "Penalized AR-LASSO"]:
        wins[baseline] = int(sum(rmse(g.HEALTH_GDP, g.LASSO) < rmse(g.HEALTH_GDP, g[baseline]) for _, g in core.groupby("Country_EN")))
    return {
        "verification_scope": "Recalculation from archived observation-level forecasts; no model refitting or upstream-data reconstruction",
        "forecast_rows": n,
        "countries": int(core.Country_EN.nunique()),
        "forecast_year_blocks": int(core.Year.nunique()),
        "same_forecast_max_abs_difference": max_differences,
        "LASSO_RMSE": rmse(core.HEALTH_GDP, core.LASSO),
        "persistence_RMSE": rmse(core.HEALTH_GDP, core.Persistence),
        "delta_RMSE": point,
        "main_country_CI_seed_0": main_interval,
        "stored_core_bootstrap_draw_max_abs_difference": max_draw_difference,
        "additional_country_CI_seed_20261031": intervals["country"],
        "additional_forecast_year_CI_same_rng_after_country_draws": intervals["forecast_year"],
        "bootstrap_replicates_per_interval": 5000,
        "percentile_rule": "numpy.quantile at 0.025 and 0.975 with default linear interpolation",
        "two_way_variance": variance,
        "two_way_standard_error": se,
        "two_way_t": statistic,
        "reference_degrees_freedom": int(degrees_freedom),
        "two_sided_p": p_two_sided,
        "whole_year_signflip_patterns": len(distribution),
        "whole_year_signflip_two_sided_p": signflip,
        "descriptive_country_win_counts": wins,
        "interpretive_limits": [
            "Country resampling preserves within-country paths but not common international shocks.",
            "Whole-year resampling retains within-year cross-country shocks but does not preserve dependence across different years.",
            "The 256-pattern sign-flip calculation assumes independently sign-symmetric annual loss aggregates; it is a sensitivity check rather than a serial-correlation correction.",
            "The two country intervals differ only because they use separate seeded Monte Carlo streams on identical observations and forecasts.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.archive_root.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
