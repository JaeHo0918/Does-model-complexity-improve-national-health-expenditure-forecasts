#!/usr/bin/env python3
"""Rebuild the five main manuscript figures from archived numerical outputs.

No model is fitted and no source observation is generated or altered here.
Each chart reads the numerical files listed in figure_metadata.json. Figure 1
is a schematic of the archived protocol, with counts read from the data.

Usage:
    python rebuild_submission_figures.py --archive-root ARCHIVE --output-dir OUT

Requires numpy, pandas, matplotlib and Pillow. Outputs are exactly 4200 pixels
wide at 300 dpi. Layouts and type sizes are designed for a 6.7-inch display
width in the manuscript; aspect ratios allow readable labels at that size.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import platform

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Patch, Polygon, Rectangle
from matplotlib.ticker import FixedLocator, FuncFormatter, NullFormatter
import numpy as np
import pandas as pd
from PIL import Image


COLORS = {
    "Persistence": "#222222", "AR(1)": "#087DB3", "LASSO": "#D95F02",
    "ARX-LASSO": "#D95F02", "Structural k-NN": "#909090",
    "Social-demographic": "#0076B2", "Political-institutional": "#CA79A7",
    "Environmental": "#009E73", "Fiscal, financing and economic": "#E69F00",
    "Lagged outcome": "#222222",
}
MARKERS = {"Persistence": "s", "AR(1)": "o", "LASSO": "D", "ARX-LASSO": "D", "Structural k-NN": "^"}
DOMAIN_FEATURES = {
    "Social-demographic": ["FERT_RATE", "YOUTH_UNEMP", "UNEMP", "POP_LOG"],
    "Political-institutional": ["EGAL_DEM_INDEX", "EXPR_INFO_FREE", "JUSTICE_ACCESS"],
    "Environmental": ["RENEW_ENERGY", "WATER_PC", "PM25_LOG", "GHG_LOG"],
    "Fiscal, financing and economic": ["PHE_CHE", "OOP_CHE", "GDP_PC", "GDP_DEFL", "PPI", "CPI", "CA_GDP", "FISCAL_BAL_GDP", "REV_GDP", "EXP_GDP"],
    "Lagged outcome": ["HEALTH_GDP"],
}
FEATURE_DOMAIN = {"L1_" + f: d for d, fs in DOMAIN_FEATURES.items() for f in fs}
FEATURE_LABELS = {
    "L1_HEALTH_GDP": "Lagged health expenditure share",
    "L1_EXPR_INFO_FREE": "Freedom of expression / information",
    "L1_YOUTH_UNEMP": "Youth unemployment",
    "L1_GHG_LOG": "ln GHG emissions",
    "L1_UNEMP": "Total unemployment",
    "L1_PHE_CHE": "Public financing share",
    "L1_POP_LOG": "ln population",
    "L1_CA_GDP": "Current-account balance",
    "L1_FISCAL_BAL_GDP": "Fiscal balance",
    "L1_JUSTICE_ACCESS": "Access to justice",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def rmse(y, pred) -> float:
    return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(pred)) ** 2)))


def mse_skill(y, pred, persistence) -> float:
    return float(100 * (1 - np.mean((np.asarray(y) - np.asarray(pred)) ** 2) /
                         np.mean((np.asarray(y) - np.asarray(persistence)) ** 2)))


class Inputs:
    def __init__(self, root: Path):
        self.root = root
        self.used = {}

    def file(self, relative: str) -> Path:
        p = self.root / relative
        if not p.is_file():
            raise FileNotFoundError(f"Required archived input is missing: {relative}")
        self.used[relative] = {"sha256": sha256(p), "size_bytes": p.stat().st_size}
        return p

    def csv(self, relative: str) -> pd.DataFrame:
        return pd.read_csv(self.file(relative))

    def js(self, relative: str):
        return json.loads(self.file(relative).read_text(encoding="utf-8-sig"))


def style():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 17,
        "axes.labelsize": 18, "axes.titlesize": 18,
        "xtick.labelsize": 17, "ytick.labelsize": 17,
        "legend.fontsize": 16, "axes.spines.top": False,
        "axes.spines.right": False, "axes.linewidth": 1.1,
        "lines.linewidth": 2.4, "lines.markersize": 8.5,
        "axes.edgecolor": "#333333", "text.color": "#222222",
        "axes.labelcolor": "#222222", "xtick.color": "#333333",
        "ytick.color": "#333333", "savefig.facecolor": "white",
        "figure.facecolor": "white", "axes.unicode_minus": True,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    })


def save(fig, out: Path, number: int, height_px: int, info: dict, summary: dict):
    fig.set_size_inches(14, height_px / 300)
    target = out / f"Figure_{number}.png"
    buffer = io.BytesIO()
    fig.savefig(buffer, dpi=300, facecolor="white", metadata={"Software": "Matplotlib manuscript figure rebuild"})
    plt.close(fig)
    png = buffer.getvalue()
    with Image.open(io.BytesIO(png)) as im:
        assert im.size == (4200, height_px), (target.name, im.size)
        im.verify()
    temporary = target.with_suffix(".png.tmp")
    temporary.write_bytes(png)
    temporary.replace(target)
    assert target.read_bytes() == png, f"PNG write verification failed: {target.name}"
    info.update({"file": target.name, "width_pixels": 4200, "height_pixels": height_px,
                 "dpi": 300, "sha256": sha256(target)})
    summary[f"Figure_{number}"] = info
    print(f"Created {target.name}: 4200 x {height_px}")


def figure1(inp: Inputs, out: Path, summary: dict):
    raw_path = "core/data/raw/source_dataset_762_utf8.csv"
    aligned_path = "core/data/analysis/analysis_dataset_one_year_ahead.csv"
    pred_path = "core/outputs/predictions/core_predictions.csv"
    bridge_path = "core/outputs/predictions/postperiod_bridge_predictions.csv"
    audit_path = "core/outputs/data_audit.json"
    protocol_path = "core/metadata/seeds_and_protocols.json"
    provenance_path = "documentation/data_provenance.json"
    raw, aligned = inp.csv(raw_path), inp.csv(aligned_path)
    pred, bridge = inp.csv(pred_path), inp.csv(bridge_path)
    audit, prov = inp.js(audit_path), inp.js(provenance_path)
    inp.js(protocol_path)
    alpha = inp.js("core/outputs/headline_results.json")["core_alpha"]
    ncore, ccore = len(raw), raw.Country_EN.nunique()
    nalign, calign = len(aligned), aligned.Country_EN.nunique()
    years = sorted(pred.Year.unique())
    countpost = bridge[bridge.Year.between(2021, 2024)].groupby("Outcome").size().to_dict()
    assert prov["date_of_source_data_extraction"] == "2026-04-02"
    # Coordinates below are in intended manuscript inches. Scaling all type
    # sizes by 14/6.7 gives the stated point sizes when the PNG is 6.7 in wide.
    fig = plt.figure(figsize=(14, 14))
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 6.7); ax.set_ylim(0, 6.7); ax.axis("off")
    scale = 14 / 6.7
    lane_colors = ["#25466A", "#A5682F", "#2E765C", "#65528D", "#A34443", "#293845"]

    def box(x, y, w, h, letter, title, color, body="", bodyfont=8.8):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=.055", fc="white", ec="#C8CDD3", lw=.65*scale))
        ax.add_patch(FancyBboxPatch((x, y+h-.28), w, .28, boxstyle="round,pad=0,rounding_size=.055", fc=color+"14", ec="none"))
        ax.add_patch(Rectangle((x, y), .035, h, color=color, lw=0))
        ax.add_patch(FancyBboxPatch((x+.10, y+h-.225), .18, .18, boxstyle="round,pad=0,rounding_size=.035", fc=color, ec="none"))
        ax.text(x+.19, y+h-.135, letter, fontsize=9*scale, weight="bold", ha="center", va="center", color="white")
        ax.text(x+.37, y+h-.14, title, fontsize=9.5*scale, weight="bold", va="center")
        if body:
            ax.text(x+.13, y+h-.37, body, fontsize=bodyfont*scale, va="top", linespacing=1.17, color="#30383F")

    def down(y1, y2):
        ax.annotate("", xy=(3.35, y2), xytext=(3.35, y1), arrowprops={"arrowstyle":"-|>", "color":"#7C8793", "lw":.7*scale, "mutation_scale":7*scale})

    box(.12,5.18,3.14,1.38,"A","Data and targets",lane_colors[0],
        f"Core: {ncore:,} country-year records\n"
        f"{ccore} countries, 2000–2020\n"
        f"Aligned: {nalign:,} one-year pairs; {calign} countries\n"
        "Inputs at t − 1; outcome at t\n"
        "Targets: current and government health\n"
        "expenditure as a share of GDP")
    box(3.44,5.18,3.14,1.38,"B","Predictor preparation",lane_colors[1],
        "Exclude same-year predictors and\n"
        "per-capita health-spending inputs.\n"
        f"Identity audit: R² = {audit['reconstruction_R2']:.3f}.\n"
        "Fit scaling within each training set.\n"
        "Select the LASSO penalty before 2013;\n"
        "keep it fixed for annual refits.")
    down(5.14,5.045)

    box(.12,2.93,6.46,2.08,"C","Validation protocols",lane_colors[2])
    protocols = [
        ("P1  Temporal", "Prior outcome years only; expanding-window estimation.\n"
         f"Forecast {years[0]}–{years[-1]}: {len(pred)} forecasts; α = {alpha:g}."),
        ("P2  Country-grouped", "Five country folds; test countries excluded from fitting.\n"
         f"All years in training countries; reused α = {alpha:g}; retrospective."),
        ("P3  Spatiotemporal", "Same test-country folds, excluded from fitting; prior years only.\n"
         f"Annual forecasts for {years[0]}–{years[-1]}; reused α = {alpha:g}."),
    ]
    for i,(title,body) in enumerate(protocols):
        yt=4.61-i*.42
        if i:
            ax.plot([.25,6.45],[yt+.075,yt+.075],color="#DDE5E0",lw=.5*scale)
        ax.text(.25,yt,title,fontsize=8.6*scale,weight="bold",va="top",color=lane_colors[2])
        ax.text(1.95,yt,body,fontsize=8.6*scale,va="top",linespacing=1.15)
    ax.add_patch(FancyBboxPatch((.25,3.055),6.20,.385,boxstyle="round,pad=0,rounding_size=.035",fc="#EDF4F0",ec="none"))
    ax.text(.36,3.36,
        "P2/P3 do not use nested country-fold tuning. Earlier observations from test countries\n"
        "may have informed the reused core penalty.",
        fontsize=8.0*scale,va="top",linespacing=1.17,color="#285B47")
    down(2.89,2.795)

    box(.12,1.20,3.14,1.56,"D","Comparisons and attribution",lane_colors[3],
        "5,000 paired resamples by country or year.\n"
        f"{len(years)} forecast-year blocks; year resampling\n"
        "does not preserve serial dependence.\n"
        "Two-way clustered loss tests, year\n"
        "sign flips and model-search bootstraps.\n"
        "Out-of-sample linear SHAP, grouped\n"
        "permutation and domain ablation.\n"
        "Attribution is not causal.",bodyfont=8.5)
    box(3.44,1.20,3.14,1.56,"E","Current-release evaluation",lane_colors[4],
        f"2021–2024: {countpost['CHE/GDP']} CHE/GDP forecasts;\n"
        f"{countpost['Government/GDP']} government/GDP forecasts.\n"
        "2024 partial coverage: 21 and 7 countries.\n"
        "WHO update: December 2025.\n"
        "Extraction: 2 April 2026 (author-reported).\n"
        "Same restricted inputs and pre-2013 tuning;\n"
        "annual refits for 2013–2020 and 2021–2024.\n"
        "Historical vintages unavailable; not real time.",bodyfont=8.5)
    down(1.16,1.065)

    box(.12,.12,6.46,.91,"F","Monitoring implication",lane_colors[5],
        "Use persistence as the benchmark. Require repeated, decision-relevant out-of-sample gains\n"
        "and calibrated uncertainty before adopting a more complex model.\n"
        "This monitoring principle is proposed; no universal operating rule is established.")
    save(fig,out,1,4200,{"inputs":[raw_path,aligned_path,pred_path,bridge_path,audit_path,protocol_path,provenance_path,"core/outputs/headline_results.json"],
         "kind":"Protocol schematic with verified counts", "counts":{"source_records":ncore,"source_countries":ccore,"aligned_records":nalign,"aligned_countries":calign,"core_forecasts":len(pred),"forecast_year_blocks":len(years),"post_period_forecasts":countpost},
         "qualifications":["Fixed pre-2013 core penalty is reused in country-grouped and spatiotemporal validation; no nested tuning is claimed.","Extraction date is author-reported.","Reference-year alignment does not establish historical availability.","Monitoring implication is a proposal, not a validated universal rule."]},summary)


def figure2(inp: Inputs,out: Path,summary: dict):
    pp="core/outputs/predictions/core_predictions.csv"; tp="core/outputs/tables/table_core_performance.csv"
    d=inp.csv(pp); t=inp.csv(tp).set_index("Model")
    annual=[]; pooled=[]
    for yr,g in d.groupby("Year",sort=True):
        for m in ["Persistence","AR(1)","LASSO","Structural k-NN"]:
            annual.append({"year":int(yr),"model":m,"N":len(g),"RMSE":rmse(g.HEALTH_GDP,g[m])})
    for m in t.index:
        val=rmse(d.HEALTH_GDP,d[m]); skill=mse_skill(d.HEALTH_GDP,d[m],d.Persistence)
        assert np.isclose(val,t.at[m,"RMSE"],atol=1e-10)
        assert np.isclose(skill,t.at[m,"MSE_skill_pct"],atol=1e-9)
        pooled.append({"model":m,"RMSE":val,"MSE_skill_pct":skill})
    annual=pd.DataFrame(annual); pooled=pd.DataFrame(pooled).set_index("model")
    ars=pooled.at["AR(1)","MSE_skill_pct"]; struct=pooled.at["LASSO","MSE_skill_pct"]-ars
    fig=plt.figure(figsize=(14,7.2))
    a=fig.add_axes([.085,.20,.365,.66]); b=fig.add_axes([.695,.34,.22,.52])
    fig.text(.022,.93,"A",fontsize=25,weight="bold"); fig.text(.53,.93,"B",fontsize=25,weight="bold")
    fig.text(.09,.94,"Annual forecast error",fontsize=18);fig.text(.585,.94,"Pooled forecast skill",fontsize=18)
    a.axvspan(2019.5,2020.5,color="#D95F02",alpha=.10,zorder=0)
    for m in ["Persistence","AR(1)","LASSO","Structural k-NN"]:
        z=annual[annual.model==m]
        a.plot(z.year,z.RMSE,color=COLORS[m],marker=MARKERS[m],ls="--" if m=="Structural k-NN" else "-",mfc="white" if m=="Structural k-NN" else COLORS[m],label={"LASSO":"Dynamic LASSO"}.get(m,m))
    a.set_yscale("log");a.set_ylim(.15,1.15);a.set_xlim(2012.7,2020.5)
    a.set_xticks(range(2013,2021));a.tick_params(axis="x",labelsize=16.5)
    a.yaxis.set_major_locator(FixedLocator([.2,.3,.4,.6,.8,1]));a.yaxis.set_major_formatter(FuncFormatter(lambda x,_:f"{x:.1f}"));a.yaxis.set_minor_formatter(NullFormatter())
    a.grid(axis="y",color="#E2E2E2",lw=.8);a.set_axisbelow(True)
    a.set_xlabel("Forecast year");a.set_ylabel("RMSE (percentage points; log scale)",fontsize=18)
    a.legend(loc="upper left",fontsize=15.7,frameon=False,ncol=2,columnspacing=.65,handlelength=1.8,handletextpad=.5)
    order=["LASSO","Elastic Net","AR(1)","Penalized AR-LASSO","OLS","Persistence","SVR","Country FE + trend Ridge","Gradient Boosting"]
    y=np.arange(len(order))[::-1]
    for yi,m in zip(y,order):
        v=pooled.at[m,"MSE_skill_pct"]
        if m=="LASSO":
            b.barh(yi,ars,color="#F2B183",height=.61);b.barh(yi,struct,left=ars,color=COLORS["LASSO"],height=.61)
        elif m=="Persistence": b.plot(0,yi,"s",color=COLORS[m],ms=7)
        else: b.barh(yi,v,color=COLORS.get(m,"#83A8C9") if v>0 else "#BDBDBD",height=.61)
        b.text(v+.32 if v>0 else .45,yi,f"{v:+.1f}" if m!="Persistence" else "0.0",ha="left",va="center",fontsize=17)
        b.text(1.24,yi,f"{pooled.at[m,'RMSE']:.3f}",transform=b.get_yaxis_transform(),ha="center",va="center",fontsize=17,clip_on=False)
    b.set_yticks(y,[{"LASSO":"Dynamic LASSO","Country FE + trend Ridge":"Country FE + trend Ridge"}.get(m,m) for m in order]);b.tick_params(axis="y",length=0,pad=8,labelsize=16.7)
    b.set_xlim(-5.1,11);b.set_ylim(-.65,8.7);b.set_xticks([-4,0,4,8]);b.axvline(0,color="#333333",lw=1.1)
    b.spines["left"].set_visible(False);b.set_xlabel("MSE skill versus persistence (%)",fontsize=17)
    b.text(1.24,1.025,"RMSE",transform=b.transAxes,ha="center",fontsize=17,weight="bold")
    fig.patches.extend([Rectangle((.535,.175),.015,.020,transform=fig.transFigure,fc="#F2B183",ec="none"),Rectangle((.535,.120),.015,.020,transform=fig.transFigure,fc=COLORS["LASSO"],ec="none")])
    fig.text(.56,.175,f"AR(1) benchmark improvement: {ars:.2f} points",fontsize=16.5)
    fig.text(.56,.120,f"Additional structural predictors: {struct:.2f} points",fontsize=16.5)
    fig.text(.535,.025,"Sequential, specification-dependent comparison;\nno unique or causal attribution.",fontsize=15.8,color="#555555",va="bottom",linespacing=1.15)
    save(fig,out,2,2160,{"inputs":[pp,tp],"annual_values":annual.to_dict("records"),"pooled_values":pooled.reset_index().to_dict("records"),
        "lasso_skill_accounting":{"estimated_AR1_benchmark_improvement_percentage_points":ars,"subsequent_structural_improvement_percentage_points":struct,"interpretation":"Sequential, specification-dependent loss differences; neither pure shrinkage nor causal or unique feature attribution."}},summary)


def bridge_checks(inp: Inputs):
    pp="core/outputs/predictions/postperiod_bridge_predictions.csv";tp="core/outputs/tables/table_same_information_bridge.csv"
    d=inp.csv(pp);t=inp.csv(tp)
    for _,r in t.iterrows():
        start,end=map(int,r.Window.split("-"));g=d[(d.Outcome==r.Outcome)&d.Year.between(start,end)]
        assert len(g)==r.N
        for model,col in [("Persistence","Persistence_RMSE"),("AR(1)","AR1_RMSE"),("ARX-LASSO","ARX_LASSO_RMSE")]:
            assert np.isclose(rmse(g.y,g[model]),r[col],atol=1e-10)
    return d,t,[pp,tp]


def figure3(inp: Inputs,out: Path,summary: dict):
    d,t,files=bridge_checks(inp);p=d[d.Year.between(2021,2024)]
    fig=plt.figure(figsize=(14,6.5));axes=[fig.add_axes([.08,.285,.40,.515]),fig.add_axes([.565,.285,.40,.515])]
    handles=[Line2D([0],[0],color=COLORS[m],marker=MARKERS[m],label=m) for m in ["Persistence","AR(1)","ARX-LASSO"]]
    fig.legend(handles=handles,loc="upper center",bbox_to_anchor=(.54,.998),ncol=3,frameon=False,fontsize=18)
    values=[]
    for ax,outcome,letter,title in zip(axes,["CHE/GDP","Government/GDP"],["A","B"],["Current health expenditure / GDP","Government health expenditure / GDP"]):
        g=p[p.Outcome==outcome];yrs=sorted(g.Year.unique());n2024=g[g.Year==2024].Country_EN.nunique()
        ax.axvspan(2023.5,2024.45,color="#E7E7E7",alpha=.8,zorder=0)
        for m in ["Persistence","AR(1)","ARX-LASSO"]:
            vals=[rmse(g[g.Year==yr].y,g[g.Year==yr][m]) for yr in yrs]
            ax.plot(yrs[:3],vals[:3],color=COLORS[m],marker=MARKERS[m],label=m)
            ax.plot(yrs[2:],vals[2:],color=COLORS[m],ls="--")
            ax.plot(yrs[-1],vals[-1],marker=MARKERS[m],color=COLORS[m],mfc="white",mew=2.1,ls="none",ms=8)
            for yr,v in zip(yrs,vals): values.append({"outcome":outcome,"year":int(yr),"model":m,"RMSE":v,"N":int((g.Year==yr).sum())})
        ax.set_ylim(0,1.0);ax.set_xlim(2020.6,2024.45);ax.set_xticks(yrs);ax.set_yticks(np.arange(0,1.01,.2))
        ax.grid(axis="y",color="#DDDDDD",lw=.85);ax.set_axisbelow(True);ax.set_xlabel("Forecast year",labelpad=6)
        ax.text(-.07,1.095,letter,transform=ax.transAxes,fontsize=25,weight="bold")
        ax.text(.015,1.10,title,transform=ax.transAxes,fontsize=18,va="center")
        ax.text(2024,.93,f"2024 partial\ncoverage\nn = {n2024}",ha="center",va="top",fontsize=15.8,color="#555555")
        if outcome=="CHE/GDP":ax.set_ylabel("Annual RMSE (percentage points)",fontsize=18)
        else:ax.tick_params(axis="y",labelleft=False)
        xpos=ax.get_position().x0
        fig.text(xpos,.12,f"Pooled 2021–2024 RMSE (n = {len(g)})",fontsize=16.3,weight="bold")
        fig.text(xpos,.062,"  ".join(f"{m} {rmse(g.y,g[m]):.3f}" for m in ["Persistence","AR(1)","ARX-LASSO"]),fontsize=15.8)
    save(fig,out,3,1950,{"inputs":files,"annual_values":values,"partial_2024":{"CHE/GDP":21,"Government/GDP":7},"calculation":"RMSE calculated from archived observation-level predictions; 2024 markers are open and connected with dashed lines."},summary)


def figure4(inp: Inputs,out: Path,summary: dict):
    d,t,files=bridge_checks(inp);fig=plt.figure(figsize=(14,6.9))
    a=fig.add_axes([.24,.23,.32,.57]);b=fig.add_axes([.715,.23,.255,.57])
    handles=[Line2D([0],[0],color=COLORS[m],marker=MARKERS[m],ls="none",ms=9,label=m) for m in ["Persistence","AR(1)","ARX-LASSO"]]
    fig.legend(handles=handles,loc="upper center",bbox_to_anchor=(.52,.995),ncol=3,frameon=False,fontsize=18)
    fig.text(.023,.875,"A",fontsize=25,weight="bold");fig.text(.105,.88,"Pooled RMSE with restricted information",fontsize=17)
    fig.text(.625,.875,"B",fontsize=25,weight="bold");fig.text(.695,.88,"ARX-LASSO skill",fontsize=17)
    order=[("CHE/GDP","2013-2020"),("CHE/GDP","2021-2024"),("Government/GDP","2013-2020"),("Government/GDP","2021-2024")]
    ys=[3,2,1,0];labels=[]
    for yi,(oc,window) in zip(ys,order):
        r=t[(t.Outcome==oc)&(t.Window==window)].iloc[0]
        vals=[r.Persistence_RMSE,r.AR1_RMSE,r.ARX_LASSO_RMSE]
        a.hlines(yi,min(vals),max(vals),color="#CBCBCB",lw=5,zorder=1)
        for m,v in zip(["Persistence","AR(1)","ARX-LASSO"],vals):a.plot(v,yi,marker=MARKERS[m],color=COLORS[m],ms=10,ls="none",zorder=3)
        labels.append(window.replace("-","–")+f"  (n = {int(r.N)})")
    a.set_yticks(ys,labels);a.tick_params(axis="y",length=0,labelsize=16.5,pad=9);a.spines["left"].set_visible(False)
    a.axhline(1.5,color="#D9D9D9",lw=1.1);a.set_ylim(-.6,3.6);a.set_xlim(.38,.625);a.set_xticks([.40,.45,.50,.55,.60]);a.grid(axis="x",color="#E6E6E6");a.set_axisbelow(True)
    a.set_xlabel("RMSE (percentage points)",fontsize=18,labelpad=7)
    a.text(-.67,2.5,"CHE/GDP",transform=a.get_yaxis_transform(),rotation=90,va="center",fontsize=18,weight="bold")
    a.text(-.67,.5,"Government/GDP",transform=a.get_yaxis_transform(),rotation=90,va="center",fontsize=18,weight="bold")
    b.axhspan(-14,0,color="#F5F5F5",zorder=0);b.axhline(0,color="#333333",lw=1.3)
    for oc,c,ls,fill in [("CHE/GDP",COLORS["ARX-LASSO"],"-",COLORS["ARX-LASSO"]),("Government/GDP","#914400","--","white")]:
        vals=[float(t[(t.Outcome==oc)&(t.Window==p)].iloc[0].ARX_skill_pct) for p in ["2013-2020","2021-2024"]]
        b.plot([0,1],vals,color=c,marker="D",ls=ls,mfc=fill,mew=2,ms=10,label=oc)
        b.annotate(f"{vals[0]:+.1f}",(0,vals[0]),xytext=(-11,11 if oc=="CHE/GDP" else -17),textcoords="offset points",ha="right",color=c,fontsize=17)
        b.annotate(f"{vals[1]:+.1f}",(1,vals[1]),xytext=(10,-1),textcoords="offset points",ha="left",va="center",color=c,fontsize=17)
    b.set_xlim(-.4,1.55);b.set_ylim(-14,8.2);b.set_xticks([0,1],["2013–2020","2021–2024"]);b.set_ylabel("MSE skill versus persistence (%)",fontsize=18)
    b.text(.98,.985,"Better than persistence",transform=b.transAxes,fontsize=15.8,color="#777777",style="italic",va="top",ha="right")
    b.text(.03,.055,"Worse than persistence",transform=b.transAxes,fontsize=15.8,color="#777777",style="italic")
    b.legend(loc="upper center",bbox_to_anchor=(.36,-.15),frameon=False,fontsize=15.8,ncol=2,handlelength=1.7,handletextpad=.5,columnspacing=1.0,borderaxespad=0)
    fig.text(.50,.035,"Current-release data in both periods; 2024 coverage is partial.",fontsize=16,color="#555555",ha="center")
    save(fig,out,4,2070,{"inputs":files,"plotted_values":t.to_dict("records"),"comparison":"Same restricted predictor set, pre-2013 penalty-selection rule and annual-origin refits; no causal regime-change claim."},summary)


def figure5(inp: Inputs,out: Path,summary: dict):
    sp="core/outputs/tables/table_shap_full.csv";s=inp.csv(sp).sort_values("Mean_abs_SHAP",ascending=False)
    pred=inp.csv("core/outputs/predictions/core_predictions.csv");norig=int(pred.Year.nunique())
    assert set(s.Predictor)==set(FEATURE_DOMAIN)
    total=s.Mean_abs_SHAP.sum();lag=float(s.loc[s.Predictor=="L1_HEALTH_GDP","Share_pct"].iloc[0]);struct=100-lag
    assert np.isclose(s.Share_pct.sum(),100,atol=1e-8)
    assert np.allclose(100*s.Mean_abs_SHAP/total,s.Share_pct,atol=1e-8)
    domain={}
    for name,features in DOMAIN_FEATURES.items():
        if name=="Lagged outcome":continue
        v=s.loc[s.Predictor.isin(["L1_"+x for x in features]),"Mean_abs_SHAP"].sum()
        domain[name]=float(100*v/(total*(struct/100)))
    fig=plt.figure(figsize=(14,9.8));a=fig.add_axes([.335,.415,.485,.495]);top=s.head(10)
    ys=np.arange(len(top))[::-1]
    for yi,(_,r) in zip(ys,top.iterrows()):
        col=COLORS[FEATURE_DOMAIN[r.Predictor]]
        a.hlines(yi,.0025,r.CI_high,color="#E3E3E3",lw=1.3,zorder=1)
        a.errorbar(r.Mean_abs_SHAP,yi,xerr=[[r.Mean_abs_SHAP-r.CI_low],[r.CI_high-r.Mean_abs_SHAP]],fmt="o",ms=8.5,ecolor=col,mfc=col,mec="white",mew=1.3,elinewidth=3,capsize=0,zorder=3)
        a.text(1.06,yi,f"{r.Share_pct:.1f}",transform=a.get_yaxis_transform(),ha="center",va="center",fontsize=17)
        a.text(1.235,yi,f"{int(r.Selected_origins)}/{norig}",transform=a.get_yaxis_transform(),ha="center",va="center",fontsize=17,color="#A61C3C" if r.Selected_origins<norig else "#222222")
    a.set_yticks(ys,[FEATURE_LABELS.get(x,x) for x in top.Predictor]);a.tick_params(axis="y",length=0,pad=8,labelsize=17)
    a.set_xscale("log");a.set_xlim(.0025,3.5);a.set_ylim(-.6,9.6)
    a.set_xticks([.003,.01,.03,.1,.3,1,3]);a.xaxis.set_major_formatter(FuncFormatter(lambda x,_:f"{x:g}"));a.xaxis.set_minor_formatter(NullFormatter())
    a.grid(axis="x",which="major",color="#EBEBEB",lw=.9);a.set_axisbelow(True);a.spines["left"].set_visible(False)
    a.set_xlabel("Mean absolute SHAP (percentage points; log scale)\nwith 95% country-block bootstrap interval",fontsize=17,labelpad=10)
    a.text(1.06,1.03,"Share\n(%)",transform=a.transAxes,ha="center",fontsize=17,weight="bold")
    a.text(1.235,1.03,"Selected\norigins",transform=a.transAxes,ha="center",fontsize=17,weight="bold")
    fig.text(.024,.94,"A",fontsize=25,weight="bold");fig.text(.09,.945,"Out-of-sample predictor attribution",fontsize=18)
    domain_handles=[Line2D([0],[0],ls="none",marker="o",color=COLORS[k],ms=8,label=k.replace(" and "," & ")) for k in ["Lagged outcome","Social-demographic","Political-institutional","Environmental","Fiscal, financing and economic"]]
    a.legend(handles=domain_handles,loc="lower right",bbox_to_anchor=(1.01,.025),fontsize=15.8,frameon=True,facecolor="white",edgecolor="#D9D9D9",title="Predictor domain",title_fontsize=16.3,handletextpad=.7)
    b=fig.add_axes([.335,.10,.485,.17]);b.set_xlim(0,100);b.set_ylim(-.52,1.25);b.axis("off")
    b.barh(1,lag,height=.48,color=COLORS["Lagged outcome"]);b.barh(1,struct,left=lag,height=.48,color="#A4A4A4")
    b.text(lag/2,1,f"Lagged expenditure share  {lag:.1f}%",ha="center",va="center",color="white",fontsize=17,weight="bold")
    b.text(lag+struct/2,1.31,f"{struct:.1f}%",ha="center",fontsize=17,color="#666666")
    b.add_patch(Polygon([[lag,.75],[100,.75],[100,.24],[0,.24]],fc="#E8E8E8",ec="none",zorder=0))
    left=0
    for name,pct in domain.items():
        b.barh(0,pct,left=left,height=.48,color=COLORS[name]);b.text(left+pct/2,0,f"{pct:.1f}%",ha="center",va="center",color="white",fontsize=17,weight="bold");left+=pct
    b.text(-2,1,"All predictors",ha="right",va="center",fontsize=17)
    b.text(-2,0,f"Structural {struct:.1f}%\nby domain",ha="right",va="center",fontsize=17)
    fig.text(.024,.275,"B",fontsize=25,weight="bold");fig.text(.09,.282,"Attribution shares",fontsize=18)
    fig.text(.50,.035,"SHAP describes model prediction allocation, not causal effects or forecast-skill gains.",fontsize=16,color="#555555",ha="center")
    save(fig,out,5,2940,{"inputs":[sp,"core/outputs/predictions/core_predictions.csv"],"top_ten":top.to_dict("records"),"lagged_outcome_share_pct":lag,"structural_share_pct":struct,"structural_domain_shares_pct":domain,"domain_feature_mapping":DOMAIN_FEATURES,"interval_source":"Archived 5,000-resample country-block SHAP intervals; no new uncertainty estimates are invented by the plotting script."},summary)


def main():
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--archive-root",required=True,type=Path)
    parser.add_argument("--output-dir",required=True,type=Path)
    args=parser.parse_args();root=args.archive_root.resolve();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    style();inp=Inputs(root);summary={}
    for func in [figure1,figure2,figure3,figure4,figure5]:func(inp,out,summary)
    report={"script":"rebuild_submission_figures.py","purpose":"Data-derived reproduction of the five main submission figures", "does_not_fit_models":True,"source_observations_modified":False,
            "runtime":{"python":platform.python_version(),"numpy":np.__version__,"pandas":pd.__version__,"matplotlib":matplotlib.__version__},
            "input_files":inp.used,"figures":summary}
    (out/"figure_metadata.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print("Created figure_metadata.json with exact relative inputs, SHA-256 values and plotted numerical values.")


if __name__=="__main__":main()
