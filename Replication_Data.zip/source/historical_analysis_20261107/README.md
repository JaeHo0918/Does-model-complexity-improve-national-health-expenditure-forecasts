# Exact replication materials for the November 2026 revision

Version: v2026-11-07. This is the code and data supplement designated Supplementary Material 2 in the revised manuscript. It is distinct from the statistical appendix designated Supplementary Material 1.

## Files that identify this revision

- `documentation/MAIN_ARTIFACT_MAP.csv`: every main Table 1–10 and Figure 1–5, its numerical generator, reporting script, source files and exact output.
- `revision_outputs/tables/Table_01.csv` through `Table_10.csv`: main-table presentation exports.
- `revision_outputs/figures/Figure_1.png` through `Figure_5.png`: the images embedded in the current manuscript.
- `supplement/Supplementary_Material_1_Reconciled_v2026-11-07.docx`: corrected Tables S1–S13, also intended as a separate submission supplement.
- `documentation/VERIFICATION_SCOPE.json`: computations actually rerun for this reporting revision and the limits of verification.
- `MANIFEST_SHA256.txt`: hashes of every archive member except the manifest itself.

The earlier `Frontiers_Reproducibility_Archive_v2026-10-31.zip` is retained unchanged in `original_archive/`. Its SHA-256 is `87dad0af7618b62f720dc2a5c81243de5f4bd5c9c758a3f86fe906a110cb8ab6`. The current outer ZIP checksum is provided with the ZIP and in the manuscript/response documents. It cannot be included inside its own manifest without creating a circular hash dependency. No immutable external repository commit or DOI is asserted.

## Reproduce the current presentation outputs

Use a separate output directory so that supplied historical outputs and their checksums remain untouched. The reporting and verification scripts accept explicit paths. The following commands assume the working directory is the extracted archive root:

```bash
python -m pip install -r requirements_revision.txt
python revision_scripts/build_main_tables.py --archive-root . --output-dir rerun/tables
python revision_scripts/rebuild_submission_figures.py --archive-root . --output-dir rerun/figures
python revision_scripts/verify_primary_results.py --archive-root . --output-dir rerun/verification
python revision_scripts/verify_primary_comparison.py --archive-root . --output rerun/primary_comparison_verification.json
```

The reference targeted-verification runtime was Python 3.12.14; exact package versions are in `requirements_revision.txt` and the verification JSON. The reporting scripts read numerical outputs; they do not by themselves refit the entire model collection. The primary-model verifier does refit the selected principal models and rechecks their tuning choices and data alignment. The comparison verifier independently recalculates the paired intervals and tests from stored forecasts. Floating-point tolerances are documented in their output.

## Original full numerical generators

The original programs and their historical requirements are supplied in `core/` and `additional/`. For a full rerun, use a fresh extracted copy, install the respective requirements in an appropriate isolated environment and run, in order:

```bash
python core/run_all.py
python additional/frontiers_additional_analysis.py
python additional/frontiers_attribution_sensitivity.py
python additional/matched_uncertainty.py
```

These original programs write into their original output directories; a full rerun can replace the stored outputs and environment records. The original core code contains all candidate learners and depends on statsmodels, xgboost and lightgbm. Those packages were not installed in the targeted-verification runtime used for this reporting revision. We do not claim a new execution of the complete original pipeline in that runtime. Earlier complete-run logs and results are retained.

The original core figure outputs are historical presentation assets. Generate the manuscript figures using `revision_scripts/rebuild_submission_figures.py`, not a legacy figure script. Any unchanged legacy README or metadata sentence stating that the core program was missing predates its recovery; the supplied `core/src/reproduce_analysis.py` is now available.

## Primary interval reconciliation

The primary country-block interval is [−0.0313, −0.0097] from core seed 0. The additional seed-20261031 rerun gives [−0.0311, −0.0096]. Both use the same 307 forecasts and 40 complete-country paths, 5,000 resamples and 2.5th/97.5th linear percentile quantiles. The point estimate is identical. The separately seeded Monte Carlo streams account for the small interval difference. Main Table 5 and the primary Table S1 row use the first result; Table S1 explicitly labels the second as a sensitivity.

The primary equal-squared-loss comparison is two-sided (t = 1.3898117645, df = 7, p = 0.2071820998). Eight forecast-year blocks are available; their independence is not established. Single-year bootstrap resampling does not preserve between-year serial dependence. The exhaustive sign-flip sensitivity requires sign-symmetry assumptions. Country wins 29/40 versus persistence and 27/40 versus penalized AR-LASSO are descriptive.

## Corrected protocol and horizon descriptions

The transfer routines reuse alpha = 0.01 from core pre-2013 tuning and do not perform nested country-fold tuning. Held-out countries are excluded from model estimation; their earlier observations may have informed the reused penalty. The current text and Figure 1 describe this limitation.

Main Table 8's corrected two- and three-year rows come from `additional/frontiers_new_results/horizon_strict_origin_results.csv` and the corresponding strict-horizon predictions, with 305 and 300 forecasts. Earlier core horizon rows remain historical outputs and are not substituted for these revised rows.

## Provenance boundaries

The retained source file contains 762 country-year rows. The documented initial total is 4,216 and the implied aggregate exclusions are 3,454. There is no available 4,216-row pre-filter merge or recoverable stage-by-stage deletion ledger, so exclusion reasons cannot be reconstructed.

The extraction date 2 April 2026 is author-reported. The provider update, observation reference year, extraction date and value availability at a historical forecast origin are distinct. Original retrieval logs, release-vintage snapshots and record-level observed/estimated flags are not available. Neither checksums nor reference-year lagging authenticate those missing historical facts.

## Submission declarations

The response documents provide the replacement Scope Statement, affirmative generative-AI disclosure and consistent author-contribution text. The journal portal fields and its regenerated review PDF are separate from these local files and require the final submission-stage reconciliation; no portal update is claimed by this archive.
