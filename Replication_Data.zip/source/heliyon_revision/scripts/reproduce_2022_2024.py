#!/usr/bin/env python3
"""Transparent post-2020 sensitivity calculations from stored out-of-sample forecasts.

This does NOT refit models or claim historical real-time-vintage reconstruction.
It subsets the same 2021-2024 predictions and calculates paired RMSE/MAE/MSE skill.
The cluster bootstrap below resamples complete country paths only; it cannot
quantify uncertainty attributable to between-year serial dependence.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd

def sha256(p):
    h = hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1 << 20), b''): h.update(chunk)
    return h.hexdigest()

def metrics(z, B=5000, seed=20261114):
    if len(z) < 1: raise AssertionError('empty subset')
    actual=z['actual'].to_numpy(float)
    p=z['persistence'].to_numpy(float)
    a=z['lasso'].to_numpy(float)
    r=z['ar1'].to_numpy(float)
    def rmse(vals): return float(np.sqrt(np.mean((actual-vals)**2)))
    rp,ra,rr=rmse(p),rmse(a),rmse(r)
    country=z.assign(sse_p=(z.actual-z.persistence)**2,sse_a=(z.actual-z.lasso)**2).groupby('Country_EN',sort=True).agg(n=('Country_EN','size'),sse_p=('sse_p','sum'),sse_a=('sse_a','sum'))
    rng=np.random.default_rng(seed)
    draws=rng.integers(0,len(country),size=(B,len(country)))
    n=country.n.to_numpy()[draws].sum(axis=1)
    bs_rp=np.sqrt(country.sse_p.to_numpy()[draws].sum(axis=1)/n)
    bs_ra=np.sqrt(country.sse_a.to_numpy()[draws].sum(axis=1)/n)
    ci=np.quantile(bs_ra-bs_rp,[0.025,0.975])
    return {
        'N':int(len(z)), 'countries':int(z.Country_EN.nunique()),
        'RMSE_persistence':rp, 'RMSE_ARX_LASSO':ra, 'RMSE_AR1':rr,
        'MAE_persistence':float(np.mean(abs(actual-p))),
        'MAE_ARX_LASSO':float(np.mean(abs(actual-a))),
        'MSE_skill_pct':float(100*(1-ra**2/rp**2)),
        'Delta_RMSE_ARX_minus_persistence':float(ra-rp),
        'country_block_bootstrap_95_CI_lower':float(ci[0]),
        'country_block_bootstrap_95_CI_upper':float(ci[1]),
        'bootstrap_replications':B,
        'bootstrap_unit':'country path (year dependence not modeled)',
    }

def run(archive, outdir):
    outdir.mkdir(exist_ok=True,parents=True)
    inp=archive/'additional/frontiers_new_results/restricted_post_period_all_predictions.csv'
    x=pd.read_csv(inp)
    x=x[x.Year.between(2021,2024)].copy()
    assert x[['Country_EN','Year','target']].duplicated().sum()==0
    assert not x[['actual','persistence','lasso','ar1']].isna().any().any()
    masks={
        '2021-2023 (primary post-period)':lambda y:y.between(2021,2023),
        '2021-2024 (partial 2024 added)':lambda y:y.between(2021,2024),
        '2021+2023 (exclude 2022 and 2024)':lambda y:y.isin([2021,2023]),
        '2021+2023+2024 (exclude 2022)':lambda y:y.isin([2021,2023,2024]),
        '2022 alone (diagnostic)':lambda y:y.eq(2022),
        '2024 alone (partial coverage)':lambda y:y.eq(2024),
    }
    result=[]
    for target in ['CHE_GDP','PUBLIC_GDP']:
        z=x[x.target==target]
        for label,select in masks.items():
            subset=z[select(z.Year)]
            if subset.empty: continue
            r=metrics(subset,seed=20261114+len(result))
            result.append({'Outcome':target,'Window':label,**r})
    df=pd.DataFrame(result)
    df.to_csv(outdir/'post_2020_2022_2024_sensitivity.csv',index=False,float_format='%.12f')
    codebook=pd.read_csv(archive/'core/metadata/variable_codebook.csv')
    codebook['Indicator_code_status']='Original provider series codes and extraction-vintage metadata not fully preserved for the core panel.'
    codebook.loc[codebook.Variable.eq('GGHE_GDP'),'Indicator_code_status']='Study-derived ratio; no external provider code.'
    codebook.to_csv(outdir/'variable_sources_verified_against_original_codebook.csv',index=False)
    core=pd.read_csv(archive/'core/data/raw/source_dataset_762_utf8.csv')
    unique_keys=int(core[['Country_EN','Year']].duplicated().sum())
    assert len(core)==762 and core.Country_EN.nunique()==41 and unique_keys==0
    codebook_source=[v for v in codebook.Variable if v != 'GGHE_GDP']
    assert not core[codebook_source].isna().any().any(), 'Core source has missing candidate fields'
    data={
        'analysis_definition':'Paired post-period prediction-subsetting diagnostics; original predictions are not refitted.',
        'source_forecast_path':str(inp.relative_to(archive)),'source_forecast_sha256':sha256(inp),
        'original_panel_rows':len(core),'original_panel_countries':int(core.Country_EN.nunique()),
        'original_panel_year_min':int(core.Year.min()),'original_panel_year_max':int(core.Year.max()),
        'complete_case_fields_confirmed':int(len(codebook_source)),'core_source_missing_cells':int(core[codebook_source].isna().sum().sum()),
        'core_duplicate_country_year_keys':unique_keys,
        'reported_prefilter_merge_rows':4216,
        'reported_retained_rows':762,
        'implied_aggregate_exclusions':4216-762,
        'prefilter_file_present':False,
        'bootstrap':'country-cluster percentile CI, 5,000 resamples; descriptive robustness, not joint time-country inference',
        'bootstrap_seed_base':20261114,
        'no_model_refit':True,
        'no_historical_vintage_validation':True,
        'notes':[
          '2022 and 2024 are exclusion scenarios, not alternative pre-registered evaluation windows.',
          '2024 has selective country coverage, so its inclusion changes the panel composition.',
          'All core variables in the retained source are non-missing by construction; missingness of the unretained 4216-row merge cannot be recomputed.',
          'The retained core source codebook contains 25 source fields plus one study-derived government health-expenditure ratio.'
        ],
    }
    (outdir/'analysis_verification.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
    print(df[['Outcome','Window','N','countries','RMSE_persistence','RMSE_ARX_LASSO','MSE_skill_pct','Delta_RMSE_ARX_minus_persistence','country_block_bootstrap_95_CI_lower','country_block_bootstrap_95_CI_upper']].round(5).to_string(index=False))
    print('Verified',data['original_panel_rows'],'rows,',data['complete_case_fields_confirmed'],'source fields, no missing values.')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--archive-root',type=Path,required=True)
    p.add_argument('--out-dir',type=Path,required=True)
    a=p.parse_args()
    run(a.archive_root,a.out_dir)
