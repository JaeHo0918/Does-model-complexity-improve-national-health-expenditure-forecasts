HELIYON REPLICATION PACKAGE: MAIN 2021–2023, AUXILIARY 2024 (2026-11-14)

Core complete-case country-year panel: 762 observations in 41 countries for
2000–2020. Core rolling-origin accuracy: 307 observations in 40 countries,
2013–2020. Reduced-information post-period primary evaluation: CHE/GDP n=120
and government health expenditure/GDP n=121 in 2021–2023. Partial 2024 is
used only as a coverage sensitivity, contributing 21 and seven forecasts.

Paths:
  historical_analysis_20261107/: immutable legacy data, model scripts, output,
    and supplemental tables S1–S13.
  heliyon_revision/: stored 2022 and 2024 evaluation-year exclusion diagnostics.
  final_revision_20261114/figures/: final Figures 1–5, generated from retained data.
  final_revision_20261114/tables/: revised Tables 1/6/7 and bridge source values.
  final_revision_20261114/verification/: 610 manuscript/table/figure/codebook
    consistency checks and 179 selected-model refit verification checks.
  final_revision_20261114/rebuild_final_figures.py: regenerate all five figures.
  final_revision_20261114/verify_final_tables_figures.py: compare a local copy
    of the final DOCX against outputs, data dictionaries and figure bytes.

Run the historical verification and final graphics reproduction using the
commands in README_START_HERE_KO.txt (Python dependencies described in the
legacy package requirements files).

Interpretation: The 2022 exclusion changes which forecast errors are scored;
it does not retrain models from a dataset excluding 2022. Input series are
reference-year aligned, not historical point-in-time data vintages. Country
path confidence intervals cannot capture common shocks within years.

The panel was constructed by a country-year merge followed by complete-case
selection. The unfiltered 4,216-row aggregate is part of the author-reported
selection description, not a reconstruction from the retained modeling files.
Only the selected-model and manuscript consistency tests described above are
claimed; no exhaustive original model-search refit is represented as done.
