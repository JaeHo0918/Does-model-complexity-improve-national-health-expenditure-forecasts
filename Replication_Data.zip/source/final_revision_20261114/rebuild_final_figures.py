#!/usr/bin/env python3
"""Final Figures 1–5: 2021–2023 primary, partial 2024 sensitivity.
All plotted quantities are calculated from pre-existing observation-level forecasts.
No model is fit and no source observations are modified.
"""
from pathlib import Path
import argparse, json, hashlib
import importlib.util
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

# Original unchanged figure-generation code is preserved inside historical_analysis_20261107.
# The original helper below is imported from the archived historical script, by explicit path.
def load_orig(root):
    src = root/'revision_scripts/rebuild_submission_figures.py'
    spec=importlib.util.spec_from_file_location('historical_figures',src)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def make_fig1(mod,root,out,summary):
    # Rebuild base historical schematic from source, then update its E-panel with text
    # by reexecuting original source after replacing only the text and documented counts.
    src=(root/'revision_scripts/rebuild_submission_figures.py').read_text(encoding='utf-8')
    old='''    countpost = bridge[bridge.Year.between(2021, 2024)].groupby("Outcome").size().to_dict()'''
    new='''    countpost = bridge[bridge.Year.between(2021, 2024)].groupby("Outcome").size().to_dict()\n    countmain = bridge[bridge.Year.between(2021, 2023)].groupby("Outcome").size().to_dict()'''
    assert old in src
    src=src.replace(old,new)
    old='''        f"2021–2024: {countpost['CHE/GDP']} CHE/GDP forecasts;\\n"\n        f"{countpost['Government/GDP']} government/GDP forecasts.\\n"\n        "2024 partial coverage: 21 and 7 countries.\\n"\n        "WHO update: December 2025.\\n"\n        "Extraction: 2 April 2026 (author-reported).\\n"\n        "Same restricted inputs and pre-2013 tuning;\\n"\n        "annual refits for 2013–2020 and 2021–2024.\\n"\n        "Historical vintages unavailable; not real time.",bodyfont=8.5)'''
    new='''        f"Main 2021–2023: {countmain['CHE/GDP']} CHE/GDP forecasts;\\n"\n        f"{countmain['Government/GDP']} government/GDP forecasts.\\n"\n        f"With 2024: {countpost['CHE/GDP']} and {countpost['Government/GDP']} forecasts.\\n"\n        "2024 partial: 21 and 7 countries only.\\n"\n        "WHO update: December 2025.\\n"\n        "Extraction: 2 April 2026 (author-reported).\\n"\n        "Same restricted inputs; annual-origin refits.\\n"\n        "Historical vintages unavailable; not real time.",bodyfont=8.3)'''
    assert old in src
    src=src.replace(old,new)
    src=src.replace('"post_period_forecasts":countpost}', '"primary_post_period_forecasts":countmain,"post_period_plus_2024_forecasts":countpost}')
    context={"__file__":str(root/'revision_scripts/rebuild_submission_figures.py'),"__name__":"__main_fig1_patch__"}
    exec(compile(src,str(root/'revision_scripts/rebuild_submission_figures.py'),'exec'),context)
    context['figure1'](mod.Inputs(root),out,summary)

def make_fig3(mod,root,out,summary):
    d=pd.read_csv(root/'core/outputs/predictions/postperiod_bridge_predictions.csv')
    p=d[d.Year.between(2021,2024)]
    fig=plt.figure(figsize=(14,6.6));axes=[fig.add_axes([.08,.275,.40,.525]),fig.add_axes([.565,.275,.40,.525])]
    handles=[Line2D([0],[0],color=mod.COLORS[m],marker=mod.MARKERS[m],label=m) for m in ['Persistence','AR(1)','ARX-LASSO']]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.54,.997),ncol=3,frameon=False,fontsize=18)
    vals=[]
    for ax,outcome,letter,title in zip(axes,['CHE/GDP','Government/GDP'],['A','B'],['Current health expenditure / GDP','Government health expenditure / GDP']):
        g=p[p.Outcome==outcome];yrs=sorted(g.Year.unique());n24=g[g.Year==2024].Country_EN.nunique();prim=g[g.Year<=2023]
        ax.axvspan(2023.5,2024.45,color='#EBEBEB',alpha=.85,zorder=0)
        for m in ['Persistence','AR(1)','ARX-LASSO']:
            series=[mod.rmse(g[g.Year==yr].y,g[g.Year==yr][m]) for yr in yrs]
            ax.plot(yrs[:3],series[:3],color=mod.COLORS[m],marker=mod.MARKERS[m])
            ax.plot(yrs[2:],series[2:],color=mod.COLORS[m],ls='--')
            ax.plot(yrs[-1],series[-1],marker=mod.MARKERS[m],color=mod.COLORS[m],mfc='white',mew=2,ls='none',ms=8)
            for yr,v in zip(yrs,series):vals.append({'outcome':outcome,'year':int(yr),'model':m,'RMSE':float(v),'N':int(sum(g.Year==yr))})
        ax.set_ylim(0,1);ax.set_xlim(2020.6,2024.45);ax.set_xticks(yrs);ax.set_yticks(np.arange(0,1.01,.2))
        ax.grid(axis='y',color='#DDDDDD',lw=.85);ax.set_axisbelow(True);ax.set_xlabel('Forecast year',labelpad=6)
        ax.text(-.075,1.095,letter,transform=ax.transAxes,fontsize=25,weight='bold')
        ax.text(.015,1.10,title,transform=ax.transAxes,fontsize=18,va='center')
        ax.text(2024,.95,f'2024 auxiliary\nn = {n24}',ha='center',va='top',fontsize=15.8,color='#555555')
        if outcome=='CHE/GDP':ax.set_ylabel('Annual RMSE (percentage points)',fontsize=18)
        else:ax.tick_params(axis='y',labelleft=False)
        xpos=ax.get_position().x0
        fig.text(xpos,.12,f'Primary 2021–2023 RMSE (n = {len(prim)})',fontsize=16.0,weight='bold')
        fig.text(xpos,.057,'  '.join(f'{m} {mod.rmse(prim.y,prim[m]):.3f}' for m in ['Persistence','AR(1)','ARX-LASSO']),fontsize=15.7)
    mod.save(fig,out,3,1980,{'inputs':['core/outputs/predictions/postperiod_bridge_predictions.csv'], 'annual_values':vals, 'primary_period':'2021-2023', 'partial_2024':{'CHE/GDP':21,'Government/GDP':7},'calculation':'Pooled values shown for 2021–2023; 2024 shaded and used only for sensitivity.'},summary)

def make_fig4(mod,root,out,summary):
    d=pd.read_csv(root/'core/outputs/predictions/postperiod_bridge_predictions.csv')
    rows=[]
    for outc in ['CHE/GDP','Government/GDP']:
        for beg,end,label,role in [(2013,2020,'2013–2020','preperiod'),(2021,2023,'2021–2023','primary'),(2021,2024,'2021–2024*','sensitivity')]:
            q=d[(d.Outcome==outc)&d.Year.between(beg,end)]
            r={m:mod.rmse(q.y,q[m]) for m in ['Persistence','AR(1)','ARX-LASSO']}
            rows.append(dict(outcome=outc,window=label,role=role,n=len(q),**r,skill=100*(1-r['ARX-LASSO']**2/r['Persistence']**2)))
    aData=pd.DataFrame(rows)
    fig=plt.figure(figsize=(14,7.9));a=fig.add_axes([.25,.22,.30,.60]);b=fig.add_axes([.70,.26,.275,.54])
    fig.text(.02,.89,'A',fontsize=25,weight='bold');fig.text(.11,.895,'Pooled RMSE: same restricted predictors',fontsize=17)
    fig.text(.62,.89,'B',fontsize=25,weight='bold');fig.text(.69,.895,'ARX-LASSO skill',fontsize=17)
    handles=[Line2D([0],[0],color=mod.COLORS[m],marker=mod.MARKERS[m],ls='none',ms=9,label=m) for m in ['Persistence','AR(1)','ARX-LASSO']]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.55,.998),ncol=3,frameon=False,fontsize=18)
    ypositions=[5,4,3,2,1,0];yticks=[]
    for yi,(_,r) in zip(ypositions,aData.iterrows()):
        arr=[r['Persistence'],r['AR(1)'],r['ARX-LASSO']]
        a.hlines(yi,min(arr),max(arr),color='#CECECE',lw=4,zorder=1)
        if r['role']=='sensitivity':a.axhspan(yi-.37,yi+.37,color='#F1F1F1',zorder=0)
        for m,v in zip(['Persistence','AR(1)','ARX-LASSO'],arr):
            a.plot(v,yi,marker=mod.MARKERS[m],color=mod.COLORS[m],mfc='white' if r['role']=='sensitivity' else mod.COLORS[m],mew=2 if r['role']=='sensitivity' else 0,ms=9,ls='none',zorder=3)
        yticks.append(f"{r['window']} (n={r['n']})")
    a.set_yticks(ypositions,yticks);a.tick_params(axis='y',length=0,labelsize=15,pad=8);a.spines['left'].set_visible(False)
    a.axhline(2.5,color='#AAAAAA',lw=1);a.set_ylim(-.55,5.65);a.set_xlim(.37,.71);a.set_xticks([.4,.45,.5,.55,.6,.65,.7]);a.grid(axis='x',color='#E6E6E6');a.set_axisbelow(True)
    a.set_xlabel('RMSE (percentage points)',fontsize=18,labelpad=7)
    a.text(-.65,4,'CHE/GDP',transform=a.get_yaxis_transform(),rotation=90,va='center',fontsize=18,weight='bold')
    a.text(-.65,1,'Government/GDP',transform=a.get_yaxis_transform(),rotation=90,va='center',fontsize=18,weight='bold')
    b.axhspan(-14,0,color='#F5F5F5',zorder=0);b.axhline(0,color='#333333',lw=1.2)
    for oc,c,mfc,ls in [('CHE/GDP',mod.COLORS['ARX-LASSO'],mod.COLORS['ARX-LASSO'],'-'),('Government/GDP','#914400','white','--')]:
        z=aData[aData.outcome==oc];x=[0,1,2];y=z.skill.to_list()
        b.plot(x[:2],y[:2],color=c,marker='D',ls=ls,ms=9,mfc=mfc,mew=2,label=oc)
        b.plot(x[1:],y[1:],color=c,marker='D',ls=':',ms=9,mfc='white',mew=2)
        for j,v in enumerate(y):
            dy=({0:16,1:-27,2:-27}[j] if oc=='CHE/GDP' else {0:-24,1:14,2:14}[j])
            b.annotate(f'{v:+.1f}',(j,v),xytext=(-1,dy),textcoords='offset points',ha='center',color=c,fontsize=15)
    b.set_xlim(-.3,2.3);b.set_ylim(-15,9);b.set_xticks([0,1,2],['2013–2020','2021–2023','+2024*'])
    b.tick_params(axis='x',labelsize=14);b.set_ylabel('MSE skill vs persistence (%)',fontsize=17)
    b.text(.99,.95,'Above 0 = ARX gain',transform=b.transAxes,fontsize=14,color='#666666',ha='right')
    b.legend(loc='upper center',bbox_to_anchor=(.5,-.13),frameon=False,fontsize=15,ncol=2)
    fig.text(.51,.04,'Main post-period: 2021–2023.  *Partial 2024 coverage is an auxiliary sensitivity.',ha='center',fontsize=16,color='#555555')
    mod.save(fig,out,4,2370,{'inputs':['core/outputs/predictions/postperiod_bridge_predictions.csv'], 'plotted_values':aData.to_dict('records'),'primary_postperiod':'2021-2023', 'sensitivity':'2021-2024 with selective 2024 coverage'},summary)
    aData.to_csv(out/'figure4_bridge_source.csv',index=False,float_format='%.12f')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--archive-root',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True)
    args=ap.parse_args();r=args.archive_root.resolve();o=args.output_dir.resolve();o.mkdir(exist_ok=True,parents=True)
    mod=load_orig(r);mod.style();summary={}
    make_fig1(mod,r,o,summary)
    mod.figure2(mod.Inputs(r),o,summary)
    make_fig3(mod,r,o,summary)
    make_fig4(mod,r,o,summary)
    mod.figure5(mod.Inputs(r),o,summary)
    (o/'figure_metadata_final.json').write_text(json.dumps({'figures':summary,'generation':'All charts recomputed from retained observation-level predictions; no models refit'},indent=2,ensure_ascii=False),encoding='utf-8')
    print('Figure metadata written',len(summary))
