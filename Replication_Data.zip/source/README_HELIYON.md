# Heliyon-oriented health-expenditure forecasting reproducibility archive (2026-11-14)

This archive accompanies the revised manuscript **Do Regularized Forecasting Models Add Value Beyond Persistence? National Health-Expenditure Forecasts Across 41 Countries**.

## Organization

- `historical_analysis_20261107/`: unchanged contents of the supplied November 7 historical reproducibility archive, including the retained 762-row analysis panel, archived model generators and predictions, results for Tables 1–10 / Figures 1–5, previous verification records and Supplementary Material 1 (Tables S1–S13). Internal filenames and prior-target-journal references in historical documentation are preserved solely for provenance. Those legacy references are **not** the current target journal.
- `heliyon_revision/scripts/reproduce_2022_2024.py`: new stand-alone sensitivity script, reads the historical **stored prediction-level** CSV and recalculates RMSE, MAE, MSE skill and country-path bootstrap intervals for the reported post-period windows.
- `heliyon_revision/results/post_2020_2022_2024_sensitivity.csv`: 12 country-year-window summaries for CHE/GDP and government health expenditure/GDP. The manuscript's expanded Table 6 displays the eight principal rows; the 2022-only and 2024-only outcomes are diagnostic extras.
- `heliyon_revision/results/variable_sources_verified_against_original_codebook.csv`: variable dictionary re-exported directly from the preexisting codebook, with provenance-boundary notes, supporting manuscript Appendix Table A1.
- `heliyon_revision/results/analysis_verification.json`: audit of 762 complete cases, 41 countries, 25 original variables, and 3,454 *author-reported* aggregate exclusions (4,216 minus 762).
- `heliyon_revision/verification/primary_verification.json`: newly rerun selected refits: 179 passed, 0 failed, **not** a claim that every model in the historical pipeline was rerun.
- `heliyon_revision/verification/primary_comparison_check.json`: recomputed main 307-observation LASSO/persistence paired results.
- `MANIFEST_HELIYON_SHA256.txt`: archive-member hashes, excluding the manifest itself.

## Recompute the new analyses

Create a Python environment with `numpy` and `pandas` installed. From the extracted archive root run:

```bash
python heliyon_revision/scripts/reproduce_2022_2024.py \
  --archive-root historical_analysis_20261107 \
  --out-dir rerun/heliyon
```

The 2022 exclusion removes **assessment rows** from stored forecasts; later years' prediction models **were not retrained** without 2022 training data. The manuscript describes this as an *evaluation-year sensitivity*, not an estimate of the causal impact of 2022. Year-specific paired country-block confidence intervals are conditional on the limited observed forecast years and **do not** resolve dependence among calendar years.

## Sample selection and provenance

The authors describe downloading individual source-variable datasets from WHO GHED, World Bank WDI, IMF, ILOSTAT, and V-Dem, merging by country and reference year, then applying **complete-case selection** across required analysis variables. The authors report 4,216 merged records before this selection; the retained analytical panel has 762 records in 41 countries, 2000–2020. No imputation was used. The original 4,216-row merged file, upstream downloads, provider-specific query logs, stepwise deletion counts, exact original code for several indicators, and historical release vintages were not retained. The supplied archive **does not** independently recreate those upstream stages and cannot verify missingness mechanisms among excluded rows. Provider labels in the codebook are author-supplied and checked against the archived variable dictionary, not independently re-downloaded from the original snapshot.

The 2021–2024 subset uses a distinct, reduced WHO/World Bank information set on contemporary-release observations and is **not** directly the same 22-feature specification as the original 2013–2020 model. The earlier period is additionally re-evaluated on that restricted same-information panel in the pre-existing Table 7.

## Key diagnostic findings

- For CHE/GDP, the 2021–2023 RMSE is 0.601818 (persistence) vs 0.638528 (ARX-LASSO). Removing year 2022, and restricting to 2021+2023, reduces the contrast to 0.49564 vs 0.49994.
- For government/GDP, the 2021–2023 RMSE is 0.559297 vs 0.584853, while the 2021+2023 contrast becomes 0.47424 vs 0.47515.
- Adding partial-coverage 2024 without 2022 yields CHE/GDP 0.46853 vs 0.46667; seven country records for government/GDP in 2024 are insufficient for general claims.
- The primary 2013–2020 comparison remains LASSO 0.413565 vs persistence 0.433229, two-way clustered two-sided p=0.207182. These results do not establish unconditional superiority of complex models.

## Integrity and publication notes

The exact output files may vary in insignificant floating-point digits depending on library versions; the paired assessment counts and reported four-decimal RMSEs should match. The original authors must check data-sharing permissions, approved text, funding acknowledgments, and journal-specific submission requirements before uploading. No submission, copyright clearance or author sign-off is claimed by these locally produced files.
