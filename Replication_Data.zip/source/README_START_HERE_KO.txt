Heliyon 의료비/GDP 예측 연구: 최종 수정용 재현자료 (2026-11-14)
=====================================================================

[분석 구성]
1) 2000–2020년: 41개국 762개 완전사례 국가–연도 데이터에 기반한 핵심 분석.
2) 2013–2020년: 40개국 307개 평가 예측에 대한 순차 검증.
3) 2021–2023년: 새로운 제한 정보집합의 주요 사후기간 결과
   CHE/GDP 120개 예측, 정부의료비/GDP 121개 예측.
4) 2024년 추가: CHE 21개, 정부의료비 7개만 추가되는 보조 민감도 분석.
5) 2022년 제외: 저장된 예측값 중 2022 평가 행을 제외하여 성능 재산출.
   모형을 2022년 자료 없이 새로 학습한 결과가 아닙니다.

[주요 디렉터리]
- historical_analysis_20261107/: 기존 패널, 예측결과, 재현코드, 검증 및
  부록 S1–S13이 포함된 원래 수치 분석기록입니다.
- heliyon_revision/: 2022/2024년 제외 민감도 분석코드와 결과표 등 직전
  Heliyon 수정 산출물입니다.
- final_revision_20261114/figures/: 최종 본문 Figure 1–5 (PNG).
  Figure 1, 3, 4는 2021–2023년을 주 분석으로 표시하도록 다시 제작함.
- final_revision_20261114/tables/: 수정된 Tables 1, 6, 7 및 Figure 4 근거 데이터.
- final_revision_20261114/verification/: 610개 문서·수치 정합성 검사 결과,
  주요 선택모형 재실행검증 179개 통과 결과, 그림 생성 기록.
- final_revision_20261114/rebuild_final_figures.py: 표본을 바꾸거나
  모형을 재학습하지 않고 저장된 수치자료로 Figure 1–5 생성.
- final_revision_20261114/verify_final_tables_figures.py: 최종 Word가 있을 때
  계산결과·표·그림·변수사전을 대조.

[실행 예시: Python]
패키지를 알집/ZIP 해제 후 현재 폴더를 패키지 최상단으로 설정한 상태:

  python heliyon_revision/scripts/reproduce_2022_2024.py \
    --archive-root historical_analysis_20261107 --out-dir temp_check

  python final_revision_20261114/rebuild_final_figures.py \
    --archive-root historical_analysis_20261107 --output-dir temp_figures

  python historical_analysis_20261107/revision_scripts/verify_primary_results.py \
    --archive-root historical_analysis_20261107 --output-dir temp_primary_check

  python final_revision_20261114/verify_final_tables_figures.py \
    --archive-root historical_analysis_20261107 \
    --revision-dir final_revision_20261114 \
    --manuscript /path/to/Heliyon_Health_Expenditure_Final_20261114.docx

[결과의 해석]
- 주요 비교: 2021–2023년 결과. 2024년은 제한 표본이므로 보조만 사용.
- 기초 LASSO 검증 성능: 2013–2020 0.414 vs persistence 0.433,
  의존성 보정 동등손실 검정 p = 0.207 (통계적 우월성 확립되지 않음).
- 예측연도 t-1 지표라는 명칭만으로 실제 발표 당시 사용가능한 자료였음이
  입증되는 것은 아님. 따라서 보고된 평가는 reference-year-aligned
  pseudo-out-of-sample 분석이며, 실시간 빈티지 예측 검증이 아님.
- 2022 제외는 평가연도 민감도 분석이며, 충격의 인과효과 검증이 아님.

[검증 가능 범위]
제공한 분석패널, 307개 주요 예측, 제한모형 사후기간 925개 전체 예측
(2013–2024 두 지표 합산), 주요 표·그림의 저장된 결과와 연결되는
수치들을 확인할 수 있습니다. 최초 병합 전 관측치 및 연구 당시의
공급기관 원자료 빈티지를 모두 다시 다운로드하는 절차를 포함하는 것은 아닙니다.
초기 병합 4,216건은 저자 보고 표본선정 절차이며, 762건의 분석용
완전사례 자료가 주요 분석의 직접 입력값입니다.

본 패키지는 데이터 변경·조작 없이 기존 예측을 재계산 및 검증합니다.
최종 저자 승인과 자료 재배포 권한 확인은 별도의 투고 전 절차입니다.
