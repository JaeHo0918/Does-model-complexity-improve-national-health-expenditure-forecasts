# Heliyon 최종 논문 및 재현자료 안내 (2026-11-16)

**최종 투고용 Word 파일:** `manuscript/Heliyon_Health_Expenditure_Submission_Final_20261116.docx`

기존 원고 `verification/Reference_Manuscript_20261114.docx`는 종전 분석표 수치 대조용이며, 제출용 최종본이 아닙니다.

## 최종 교정 및 번호 검증
- 본문 Table 1~13, 부록 Table A1, Figure 1~8의 번호, 표·그림 배치 및 본문 참조를 확인했습니다.
- 참고문헌 34편을 **본문 최초 인용 순서**에 맞춰 재배열하고, 인용번호와 DOI 하이퍼링크를 동기화했습니다.
- 주요 분석결과·소득군 분석·민감도 분석의 숫자는 변경하지 않았습니다. 음수 부호, 소득군 명칭, post-period 등 표기만 통일했습니다.
- 표현상 과도하게 기계적인 문장과 중복되는 작성·검증 설명은 자연스러운 학술 영어로 다듬었습니다. 실제 도구 사용에 관한 필수 AI 선언문은 정확하게 유지했습니다.

## 재현 명령
압축파일을 읽기·쓰기 가능한 폴더에 풀고, `requirements_expanded.txt`에 적힌 의존성을 준비한 후 실행합니다.

```
python run_expanded_analysis.py
python verify_expanded_results.py
```

검증 결과는 `verification/FINAL_SUBMISSION_QA_20261116.json`, 참고문헌 기록은 `verification/REFERENCE_DOI_AUDIT.txt`에 있습니다. `MANIFEST_EXPANDED_SHA256.txt`에는 압축파일 내부 파일의 SHA-256 값이 기록됩니다.

분석의 핵심 원칙: 2021~2023년은 주 사후평가 기간이고 2024년은 불완전한 표본에 대한 민감도 분석입니다. 2022년 제외는 **예측성능 채점 기간에서만 제외**한 것이며 모형 재학습은 아닙니다. 표본 내 소득군 구분은 국제기구의 공식 소득구분과 다릅니다. 국가 단위 신뢰구간만으로 세계적 공통 연도 충격을 통제할 수 없고, 분석은 실제 발표일 기준 실시간 데이터 빈티지를 복원한 것이 아닙니다.
